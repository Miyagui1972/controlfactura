# 📱 Manual de Instalación - Control de Facturas PWA

## 🌐 Acceso General (Todos los Sistemas)

La aplicación **Control de Facturas** es una Progressive Web App (PWA) que funciona directamente desde el navegador web.

### Requisitos Mínimos:
- Conexión a Internet
- Navegador web moderno (Chrome, Firefox, Edge, Safari)
- Para instalación en dispositivos: Chrome en Android, Edge en Windows

### URL de Acceso:
```
[URL_DE_LA_APLICACION]
```
*Reemplaza con la URL real después del despliegue*

### Credenciales de Prueba:
- **Email:** `john@doe.com`
- **Contraseña:** `johndoe123`

---

## 🐧 Instalación en Linux

### Opción 1: Acceso Directo desde Navegador

1. **Abrir el navegador** (Chrome, Firefox, o Chromium)
2. **Navegar a la URL** de la aplicación
3. **Iniciar sesión** con tus credenciales
4. **Usar directamente** desde el navegador

### Opción 2: Instalar como Aplicación (Chrome/Chromium)

#### Pasos:

1. **Abrir Google Chrome o Chromium**
   ```bash
   google-chrome [URL_DE_LA_APLICACION]
   # o
   chromium-browser [URL_DE_LA_APLICACION]
   ```

2. **Buscar el ícono de instalación**
   - En la barra de direcciones, lado derecho
   - Aparece un ícono de computadora con una flecha ⬇️
   - O haz clic en el menú (⋮) → "Instalar Control de Facturas"

3. **Confirmar la instalación**
   - Clic en "Instalar"
   - La aplicación se abrirá en una ventana independiente

4. **Acceder desde el menú de aplicaciones**
   - La aplicación aparecerá en tu lanzador de aplicaciones
   - Busca "Control de Facturas" en tu menú de aplicaciones

#### Crear Acceso Directo Manual (Alternativa):

```bash
# Crear archivo .desktop
sudo nano ~/.local/share/applications/control-facturas.desktop
```

**Contenido del archivo:**
```ini
[Desktop Entry]
Version=1.0
Type=Application
Name=Control de Facturas
Comment=Sistema de gestión de facturas empresariales
Exec=google-chrome --app=[URL_DE_LA_APLICACION]
Icon=accessories-calculator
Categories=Office;Finance;
Terminal=false
StartupWMClass=control-facturas
```

**Guardar y dar permisos:**
```bash
chmod +x ~/.local/share/applications/control-facturas.desktop
```

### Opción 3: Crear Alias en la Terminal (Opcional)

```bash
# Agregar al archivo .bashrc o .zshrc
echo 'alias facturas="google-chrome --app=[URL_DE_LA_APLICACION]"' >> ~/.bashrc
source ~/.bashrc

# Ahora puedes abrir la app con:
facturas
```

---

## 🪟 Instalación en Windows

### Opción 1: Acceso Directo desde Navegador

1. **Abrir el navegador** (Chrome o Microsoft Edge)
2. **Navegar a la URL** de la aplicación
3. **Iniciar sesión** con tus credenciales
4. **Usar directamente** desde el navegador

### Opción 2: Instalar como Aplicación (Recomendado)

#### Usando Google Chrome:

1. **Abrir Google Chrome**
   - Navegar a la URL de la aplicación

2. **Instalar la aplicación**
   - **Método 1:** Buscar el ícono de instalación en la barra de direcciones (⬇️)
   - **Método 2:** Menú (⋮) → "Instalar Control de Facturas..."
   - **Método 3:** Presionar `Ctrl + Shift + A` (Windows)

3. **Confirmar instalación**
   - Clic en "Instalar"
   - La aplicación se abrirá en una ventana independiente

4. **Acceder desde el Menú Inicio**
   - Busca "Control de Facturas" en el Menú Inicio
   - La aplicación aparecerá como cualquier otra app instalada

#### Usando Microsoft Edge:

1. **Abrir Microsoft Edge**
   - Navegar a la URL de la aplicación

2. **Instalar la aplicación**
   - Menú (⋯) → "Aplicaciones" → "Instalar este sitio como una aplicación"
   - O buscar el ícono de instalación en la barra de direcciones

3. **Confirmar instalación**
   - Dar un nombre (o dejar "Control de Facturas")
   - Clic en "Instalar"

4. **Anclar a la Barra de Tareas (Opcional)**
   - Clic derecho en el ícono de la aplicación
   - "Anclar a la barra de tareas"

### Opción 3: Crear Acceso Directo en el Escritorio

1. **Clic derecho en el escritorio** → "Nuevo" → "Acceso directo"

2. **Ubicación del elemento:**
   - Para Chrome:
   ```
   "C:\Program Files\Google\Chrome\Application\chrome.exe" --app=[URL_DE_LA_APLICACION]
   ```
   - Para Edge:
   ```
   "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app=[URL_DE_LA_APLICACION]
   ```

3. **Nombre del acceso directo:**
   ```
   Control de Facturas
   ```

4. **Finalizar**
   - Clic en "Finalizar"
   - Ahora puedes hacer doble clic para abrir la aplicación

---

## 📱 Instalación en Android

### Requisitos:
- Dispositivo Android 5.0 o superior
- Google Chrome instalado
- Conexión a Internet

### Pasos de Instalación:

1. **Abrir Google Chrome en tu celular**

2. **Navegar a la URL de la aplicación**
   - Escribe o pega la URL en la barra de direcciones
   - Presiona Enter

3. **Iniciar sesión**
   - Ingresa tus credenciales
   - Email: `john@doe.com`
   - Contraseña: `johndoe123`

4. **Instalar la aplicación**
   
   Aparecerá un mensaje emergente automáticamente:
   - **"Agregar Control de Facturas a la pantalla de inicio"**
   
   Si no aparece automáticamente:
   - Menú (⋮) en la esquina superior derecha
   - Seleccionar **"Agregar a pantalla de inicio"** o **"Instalar aplicación"**

5. **Confirmar instalación**
   - Clic en **"Agregar"** o **"Instalar"**
   - La aplicación se instalará en tu pantalla de inicio

6. **Abrir la aplicación**
   - Busca el ícono **"Control de Facturas"** en tu pantalla de inicio
   - Toca el ícono para abrir la aplicación
   - La aplicación se abrirá en modo pantalla completa (sin barra del navegador)

### Características en Android:

✅ **Funciona como una app nativa**
- No muestra la barra de Chrome
- Ícono en la pantalla de inicio
- Aparece en el cajón de aplicaciones
- Se puede cambiar entre apps con el botón de apps recientes

✅ **Funcionalidad offline básica**
- La interfaz se carga más rápido después de la primera visita
- Algunas funciones funcionan sin conexión

✅ **Notificaciones web**
- Recibe alertas de facturas próximas a vencer
- Notificaciones de facturas vencidas

---

## 🔐 Primer Inicio de Sesión

### Datos de Prueba:

Puedes usar estas credenciales para explorar la aplicación:

```
Email:     john@doe.com
Contraseña: johndoe123
```

La cuenta incluye datos de ejemplo:
- 2 negocios de muestra
- 3 proveedores
- 5 facturas de ejemplo
- 2 compras sin boleta

### Crear Tu Propia Cuenta:

1. Acceder a la URL de la aplicación
2. Clic en **"¿No tienes cuenta? Regístrate"**
3. Completar el formulario:
   - Nombre completo
   - Email
   - Contraseña (mínimo 6 caracteres)
   - Confirmar contraseña
4. Clic en **"Registrarse"**
5. Serás redirigido automáticamente al dashboard

---

## ❓ Solución de Problemas

### La aplicación no se carga:

- **Verificar conexión a Internet**
- **Limpiar caché del navegador:**
  - Chrome: `Ctrl + Shift + Delete` (Windows/Linux)
  - Seleccionar "Imágenes y archivos en caché"
  - Clic en "Borrar datos"

### No aparece la opción de instalar:

- **Verificar que estés usando Chrome o Edge**
- **Asegúrate de estar usando HTTPS** (conexión segura)
- **Intenta desde el menú del navegador:**
  - Chrome: Menú (⋮) → "Instalar Control de Facturas"
  - Edge: Menú (⋯) → "Aplicaciones" → "Instalar"

### No puedo iniciar sesión:

- **Verificar las credenciales**
- **Verificar que el email esté escrito correctamente**
- **Asegúrate de que la contraseña tenga al menos 6 caracteres**
- **Si olvidaste tu contraseña, contacta al administrador**

### La aplicación se ve mal en móvil:

- **Actualizar Google Chrome a la última versión**
- **Cerrar y volver a abrir la aplicación**
- **Desinstalar y volver a instalar la PWA**

### Problemas de rendimiento:

- **Cerrar otras pestañas del navegador**
- **Reiniciar el navegador**
- **Limpiar caché y datos de navegación**
- **Actualizar el navegador a la última versión**

---

## 📞 Soporte Técnico

Si encuentras problemas o necesitas ayuda adicional:

- **Documentación:** [URL_DOCUMENTACION]
- **Email de soporte:** [EMAIL_SOPORTE]
- **Reportar un error:** [URL_ISSUES]

---

## 🎉 ¡Listo!

Ahora puedes comenzar a gestionar las facturas de tus negocios desde cualquier dispositivo.

### Próximos Pasos:

1. ✅ Crear tu primer negocio
2. ✅ Agregar proveedores
3. ✅ Registrar facturas
4. ✅ Generar informes
5. ✅ Exportar a PDF

**¡Disfruta de Control de Facturas!** 🚀
