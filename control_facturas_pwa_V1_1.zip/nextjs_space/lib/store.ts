'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface NegocioActivo {
  id: string;
  nombre: string;
}

interface AppState {
  negocioActivo: NegocioActivo | null;
  setNegocioActivo: (negocio: NegocioActivo | null) => void;
}

export const useAppStore = create<AppState>()(  persist(
    (set) => ({
      negocioActivo: null,
      setNegocioActivo: (negocio) => set({ negocioActivo: negocio }),
    }),
    {
      name: 'app-storage',
    }
  )
);
