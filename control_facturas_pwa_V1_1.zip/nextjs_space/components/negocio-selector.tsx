'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useAppStore } from '@/lib/store';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Building2 } from 'lucide-react';

interface Negocio {
  id: string;
  nombre: string;
  descripcion: string | null;
}

export function NegocioSelector() {
  const session = useSession();
  const { negocioActivo, setNegocioActivo } = useAppStore();
  const [negocios, setNegocios] = useState<Negocio[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (session?.data?.user?.id) {
      fetchNegocios();
    }
  }, [session?.data?.user?.id]);

  const fetchNegocios = async () => {
    try {
      const response = await fetch('/api/negocios');
      if (response.ok) {
        const data = await response.json();
        setNegocios(data?.negocios || []);
        
        // Si no hay negocio activo pero hay negocios disponibles, seleccionar el primero
        if (!negocioActivo && data?.negocios?.length > 0) {
          setNegocioActivo({
            id: data.negocios[0].id,
            nombre: data.negocios[0].nombre,
          });
        }
      }
    } catch (error) {
      console.error('Error al cargar negocios:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectChange = (value: string) => {
    const negocio = negocios?.find((n) => n?.id === value);
    if (negocio) {
      setNegocioActivo({
        id: negocio.id,
        nombre: negocio.nombre,
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-lg">
        <Building2 className="h-4 w-4 text-gray-400" />
        <span className="text-sm text-gray-500">Cargando...</span>
      </div>
    );
  }

  if (!negocios || negocios.length === 0) {
    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-amber-50 rounded-lg">
        <Building2 className="h-4 w-4 text-amber-600" />
        <span className="text-sm text-amber-700">Sin negocios</span>
      </div>
    );
  }

  return (
    <div className="space-y-1">
      <label className="text-xs font-medium text-gray-500 px-1">
        Negocio Activo
      </label>
      <Select
        value={negocioActivo?.id || ''}
        onValueChange={handleSelectChange}
      >
        <SelectTrigger className="w-full">
          <div className="flex items-center gap-2">
            <Building2 className="h-4 w-4 text-blue-600" />
            <SelectValue placeholder="Seleccionar negocio" />
          </div>
        </SelectTrigger>
        <SelectContent>
          {negocios.map((negocio) => (
            <SelectItem key={negocio.id} value={negocio.id}>
              {negocio.nombre}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
