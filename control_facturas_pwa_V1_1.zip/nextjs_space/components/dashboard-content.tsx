'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Receipt,
  DollarSign,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';

interface DashboardStats {
  totalFacturas: number;
  facturasPagadas: number;
  facturasPorPagar: number;
  facturasAceptadas: number;
  facturasPendientes: number;
  facturasRechazadas: number;
  montoTotal: number;
  montoPagado: number;
  montoPorPagar: number;
  facturasProximasVencer: number;
}

export default function DashboardContent() {
  const [mounted, setMounted] = useState(false);
  const session = useSession();
  const router = useRouter();
  const { negocioActivo } = useAppStore();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    if (session?.status === 'loading') return;
    if (!session?.data) {
      router.push('/login');
      return;
    }
  }, [session?.data, session?.status, router, mounted]);

  useEffect(() => {
    if (negocioActivo?.id) {
      fetchStats();
    } else {
      setLoading(false);
    }
  }, [negocioActivo?.id]);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/dashboard/stats?negocioId=${negocioActivo?.id}`);
      if (response.ok) {
        const data = await response.json();
        setStats(data?.stats || null);
      }
    } catch (error) {
      console.error('Error al cargar estadísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
    }).format(amount);
  };

  if (!mounted || session?.status === 'loading') {
    return null;
  }

  if (!session?.data) {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">
            Resumen general de tu gestión de facturas
          </p>
        </div>

        {!negocioActivo && (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              No tienes un negocio seleccionado. Por favor, crea o selecciona un
              negocio desde el menú lateral o la sección de Negocios.
            </AlertDescription>
          </Alert>
        )}

        {negocioActivo && (
          <>
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-6 text-white shadow-lg">
              <h2 className="text-2xl font-bold mb-2">{negocioActivo.nombre}</h2>
              <p className="text-blue-100">Negocio activo</p>
            </div>

            {loading ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {[...Array(8)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader className="pb-2">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : stats ? (
              <>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Facturas
                  </h3>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">
                          Total Facturas
                        </CardTitle>
                        <Receipt className="h-5 w-5 text-blue-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-gray-900">
                          {stats.totalFacturas}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">
                          Aceptadas
                        </CardTitle>
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-green-600">
                          {stats.facturasAceptadas}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">
                          Pendientes
                        </CardTitle>
                        <Clock className="h-5 w-5 text-amber-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-amber-600">
                          {stats.facturasPendientes}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">
                          Rechazadas
                        </CardTitle>
                        <XCircle className="h-5 w-5 text-red-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-red-600">
                          {stats.facturasRechazadas}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Estado de Pagos
                  </h3>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">
                          Facturas Pagadas
                        </CardTitle>
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-green-600">
                          {stats.facturasPagadas}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">
                          Facturas Por Pagar
                        </CardTitle>
                        <Clock className="h-5 w-5 text-amber-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-amber-600">
                          {stats.facturasPorPagar}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow border-amber-200 bg-amber-50">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-amber-900">
                          Próximas a Vencer
                        </CardTitle>
                        <AlertTriangle className="h-5 w-5 text-amber-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-amber-600">
                          {stats.facturasProximasVencer}
                        </div>
                        <p className="text-xs text-amber-700 mt-1">
                          En los próximos 7 días
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Montos
                  </h3>
                  <div className="grid gap-4 sm:grid-cols-1 lg:grid-cols-3">
                    <Card className="hover:shadow-md transition-shadow bg-gradient-to-br from-blue-50 to-blue-100">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-blue-900">
                          Monto Total
                        </CardTitle>
                        <DollarSign className="h-5 w-5 text-blue-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-blue-900">
                          {formatCurrency(stats.montoTotal)}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow bg-gradient-to-br from-green-50 to-green-100">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-green-900">
                          Monto Pagado
                        </CardTitle>
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-green-900">
                          {formatCurrency(stats.montoPagado)}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-md transition-shadow bg-gradient-to-br from-amber-50 to-amber-100">
                      <CardHeader className="flex flex-row items-center justify-between pb-2">
                        <CardTitle className="text-sm font-medium text-amber-900">
                          Monto Por Pagar
                        </CardTitle>
                        <TrendingUp className="h-5 w-5 text-amber-600" />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-amber-900">
                          {formatCurrency(stats.montoPorPagar)}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </>
            ) : (
              <Alert>
                <AlertDescription>
                  No se pudieron cargar las estadísticas. Por favor, intenta de nuevo.
                </AlertDescription>
              </Alert>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
