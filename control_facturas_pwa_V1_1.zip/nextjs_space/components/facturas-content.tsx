'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { FileText, Plus, Pencil, Trash2, Loader2, AlertTriangle, Filter, X, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface Proveedor {
  id: string;
  nombre: string;
}

interface Factura {
  id: string;
  numeroFactura: string;
  rutEmpresa: string | null;
  nombreVendedor: string | null;
  formaPago: string;
  totalNeto: number;
  iva: number;
  total: number;
  fechaEmision: string;
  fechaVencimiento: string;
  estado: string;
  estadoPago: string;
  motivoRechazo: string | null;
  proveedor: Proveedor;
}

interface FormData {
  proveedorId: string;
  rutEmpresa: string;
  numeroFactura: string;
  fechaEmision: string;
  fechaVencimiento: string;
  nombreVendedor: string;
  formaPago: string;
  totalNeto: string;
  iva: string;
  total: string;
}

export default function FacturasContent() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const negocioActivo = useAppStore((state) => state?.negocioActivo);
  const [mounted, setMounted] = useState(false);
  const [facturas, setFacturas] = useState<Factura[]>([]);
  const [proveedores, setProveedores] = useState<Proveedor[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isEstadoDialogOpen, setIsEstadoDialogOpen] = useState(false);
  const [editingFactura, setEditingFactura] = useState<Factura | null>(null);
  const [deletingFactura, setDeletingFactura] = useState<Factura | null>(null);
  const [changingEstadoFactura, setChangingEstadoFactura] = useState<Factura | null>(null);
  const [nuevoEstado, setNuevoEstado] = useState<string>('');
  const [motivoRechazo, setMotivoRechazo] = useState<string>('');
  const [formData, setFormData] = useState<FormData>({
    proveedorId: '',
    rutEmpresa: '',
    numeroFactura: '',
    fechaEmision: '',
    fechaVencimiento: '',
    nombreVendedor: '',
    formaPago: 'credito',
    totalNeto: '',
    iva: '',
    total: ''
  });
  const [submitting, setSubmitting] = useState(false);
  
  // Filtros
  const [filters, setFilters] = useState({
    proveedorId: 'all',
    estado: 'all',
    estadoPago: 'all',
    fechaInicio: '',
    fechaFin: ''
  });
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [mounted, status, router]);

  useEffect(() => {
    if (mounted && status === 'authenticated' && negocioActivo?.id) {
      fetchProveedores();
      fetchFacturas();
    }
  }, [mounted, status, negocioActivo?.id]);

  useEffect(() => {
    if (mounted && status === 'authenticated' && negocioActivo?.id) {
      fetchFacturas();
    }
  }, [filters]);

  const fetchProveedores = async () => {
    if (!negocioActivo?.id) return;

    try {
      const response = await fetch(`/api/proveedores?negocioId=${negocioActivo.id}`);
      if (response.ok) {
        const data = await response.json();
        setProveedores(data?.proveedores ?? []);
      }
    } catch (error) {
      console.error('Error fetching proveedores:', error);
    }
  };

  const fetchFacturas = async () => {
    if (!negocioActivo?.id) return;

    try {
      setLoading(true);
      const params = new URLSearchParams({ negocioId: negocioActivo.id });
      
      if (filters.proveedorId && filters.proveedorId !== 'all') params.append('proveedorId', filters.proveedorId);
      if (filters.estado && filters.estado !== 'all') params.append('estado', filters.estado);
      if (filters.estadoPago && filters.estadoPago !== 'all') params.append('estadoPago', filters.estadoPago);
      if (filters.fechaInicio) params.append('fechaInicio', filters.fechaInicio);
      if (filters.fechaFin) params.append('fechaFin', filters.fechaFin);

      const response = await fetch(`/api/facturas?${params.toString()}`);
      if (response.ok) {
        const data = await response.json();
        setFacturas(data ?? []);
      } else {
        toast.error('Error al cargar facturas');
      }
    } catch (error) {
      console.error('Error fetching facturas:', error);
      toast.error('Error al cargar facturas');
    } finally {
      setLoading(false);
    }
  };

  const calculateIVA = (neto: string) => {
    const netoNum = parseFloat(neto || '0');
    const ivaNum = netoNum * 0.19;
    return ivaNum.toFixed(2);
  };

  const calculateTotal = (neto: string, iva: string) => {
    const netoNum = parseFloat(neto || '0');
    const ivaNum = parseFloat(iva || '0');
    const totalNum = netoNum + ivaNum;
    return totalNum.toFixed(2);
  };

  const handleNetoChange = (value: string) => {
    const newFormData = { ...formData, totalNeto: value };
    const calculatedIVA = calculateIVA(value);
    newFormData.iva = calculatedIVA;
    newFormData.total = calculateTotal(value, calculatedIVA);
    setFormData(newFormData);
  };

  const handleOpenDialog = (factura?: Factura) => {
    if (factura) {
      setEditingFactura(factura);
      setFormData({
        proveedorId: factura.proveedor.id,
        rutEmpresa: factura.rutEmpresa ?? '',
        numeroFactura: factura.numeroFactura,
        fechaEmision: format(new Date(factura.fechaEmision), 'yyyy-MM-dd'),
        fechaVencimiento: format(new Date(factura.fechaVencimiento), 'yyyy-MM-dd'),
        nombreVendedor: factura.nombreVendedor ?? '',
        formaPago: factura.formaPago,
        totalNeto: factura.totalNeto.toString(),
        iva: factura.iva.toString(),
        total: factura.total.toString()
      });
    } else {
      setEditingFactura(null);
      setFormData({
        proveedorId: '',
        rutEmpresa: '',
        numeroFactura: '',
        fechaEmision: format(new Date(), 'yyyy-MM-dd'),
        fechaVencimiento: format(new Date(), 'yyyy-MM-dd'),
        nombreVendedor: '',
        formaPago: 'credito',
        totalNeto: '',
        iva: '',
        total: ''
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingFactura(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData?.proveedorId || !formData?.numeroFactura || !formData?.totalNeto) {
      toast.error('Completa los campos requeridos');
      return;
    }

    if (!negocioActivo?.id) {
      toast.error('Selecciona un negocio activo');
      return;
    }

    try {
      setSubmitting(true);
      const url = editingFactura ? `/api/facturas/${editingFactura.id}` : '/api/facturas';
      const method = editingFactura ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          negocioId: negocioActivo.id
        })
      });

      if (response.ok) {
        toast.success(editingFactura ? 'Factura actualizada' : 'Factura creada');
        handleCloseDialog();
        fetchFacturas();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al guardar factura');
      }
    } catch (error) {
      console.error('Error submitting:', error);
      toast.error('Error al guardar factura');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenDeleteDialog = (factura: Factura) => {
    setDeletingFactura(factura);
    setIsDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setIsDeleteDialogOpen(false);
    setDeletingFactura(null);
  };

  const handleDelete = async () => {
    if (!deletingFactura) return;

    try {
      setSubmitting(true);
      const response = await fetch(`/api/facturas/${deletingFactura.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        toast.success('Factura eliminada');
        handleCloseDeleteDialog();
        fetchFacturas();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al eliminar factura');
      }
    } catch (error) {
      console.error('Error deleting:', error);
      toast.error('Error al eliminar factura');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenEstadoDialog = (factura: Factura) => {
    setChangingEstadoFactura(factura);
    setNuevoEstado('');
    setMotivoRechazo('');
    setIsEstadoDialogOpen(true);
  };

  const handleCloseEstadoDialog = () => {
    setIsEstadoDialogOpen(false);
    setChangingEstadoFactura(null);
    setNuevoEstado('');
    setMotivoRechazo('');
  };

  const handleChangeEstado = async () => {
    if (!changingEstadoFactura || !nuevoEstado) {
      toast.error('Selecciona un estado');
      return;
    }

    if (nuevoEstado === 'rechazada' && !motivoRechazo?.trim()) {
      toast.error('El motivo de rechazo es requerido');
      return;
    }

    try {
      setSubmitting(true);
      const response = await fetch(`/api/facturas/${changingEstadoFactura.id}/estado`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          estado: nuevoEstado,
          motivoRechazo: nuevoEstado === 'rechazada' ? motivoRechazo : null
        })
      });

      if (response.ok) {
        toast.success('Estado actualizado');
        handleCloseEstadoDialog();
        fetchFacturas();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al cambiar estado');
      }
    } catch (error) {
      console.error('Error changing estado:', error);
      toast.error('Error al cambiar estado');
    } finally {
      setSubmitting(false);
    }
  };

  const handleTogglePago = async (factura: Factura) => {
    const nuevoEstadoPago = factura.estadoPago === 'pagada' ? 'porPagar' : 'pagada';

    try {
      const response = await fetch(`/api/facturas/${factura.id}/pago`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estadoPago: nuevoEstadoPago })
      });

      if (response.ok) {
        toast.success('Estado de pago actualizado');
        fetchFacturas();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al actualizar estado de pago');
      }
    } catch (error) {
      console.error('Error updating pago:', error);
      toast.error('Error al actualizar estado de pago');
    }
  };

  const clearFilters = () => {
    setFilters({
      proveedorId: 'all',
      estado: 'all',
      estadoPago: 'all',
      fechaInicio: '',
      fechaFin: ''
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(value);
  };

  if (!mounted || status === 'loading') {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  if (!negocioActivo?.id) {
    return (
      <DashboardLayout>
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Selecciona un negocio activo para gestionar facturas
          </AlertDescription>
        </Alert>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Facturas</h1>
            <p className="text-muted-foreground">Gestiona las facturas de {negocioActivo?.nombre}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
            <Button onClick={() => handleOpenDialog()} className="gap-2">
              <Plus className="h-4 w-4" />
              Nueva Factura
            </Button>
          </div>
        </div>

        {/* Filters */}
        {showFilters && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filtros</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
                <div className="space-y-2">
                  <Label>Proveedor</Label>
                  <Select
                    value={filters.proveedorId}
                    onValueChange={(value) => setFilters({ ...filters, proveedorId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      {proveedores?.map?.((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Estado</Label>
                  <Select
                    value={filters.estado}
                    onValueChange={(value) => setFilters({ ...filters, estado: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="pendiente">Pendiente</SelectItem>
                      <SelectItem value="aceptada">Aceptada</SelectItem>
                      <SelectItem value="rechazada">Rechazada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Estado Pago</Label>
                  <Select
                    value={filters.estadoPago}
                    onValueChange={(value) => setFilters({ ...filters, estadoPago: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="porPagar">Por Pagar</SelectItem>
                      <SelectItem value="pagada">Pagada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Fecha Inicio</Label>
                  <Input
                    type="date"
                    value={filters.fechaInicio}
                    onChange={(e) => setFilters({ ...filters, fechaInicio: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Fecha Fin</Label>
                  <Input
                    type="date"
                    value={filters.fechaFin}
                    onChange={(e) => setFilters({ ...filters, fechaFin: e.target.value })}
                  />
                </div>
              </div>

              <Button variant="outline" onClick={clearFilters} className="gap-2">
                <X className="h-4 w-4" />
                Limpiar Filtros
              </Button>
            </CardContent>
          </Card>
        )}

        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : facturas?.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-center mb-4">
                No hay facturas registradas
              </p>
              <Button onClick={() => handleOpenDialog()} className="gap-2">
                <Plus className="h-4 w-4" />
                Crear Primera Factura
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {facturas?.map?.((factura) => (
              <Card
                key={factura?.id}
                className={`hover:shadow-lg transition-shadow ${
                  factura?.estado === 'rechazada' ? 'bg-red-50 border-red-200' : ''
                }`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="h-5 w-5 text-primary" />
                        <CardTitle className="text-xl">
                          Factura N° {factura?.numeroFactura}
                        </CardTitle>
                      </div>
                      <CardDescription className="space-y-1">
                        <div>Proveedor: <span className="font-semibold">{factura?.proveedor?.nombre}</span></div>
                        {factura?.nombreVendedor && <div>Vendedor: {factura.nombreVendedor}</div>}
                        {factura?.rutEmpresa && <div>RUT: {factura.rutEmpresa}</div>}
                      </CardDescription>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge variant={factura?.estadoPago === 'pagada' ? 'default' : 'secondary'}>
                        {factura?.estadoPago === 'pagada' ? 'Pagada' : 'Por Pagar'}
                      </Badge>
                      {factura?.estado === 'pendiente' && (
                        <Badge variant="outline">Pendiente</Badge>
                      )}
                      {factura?.estado === 'aceptada' && (
                        <Badge className="bg-green-500">Aceptada</Badge>
                      )}
                      {factura?.estado === 'rechazada' && (
                        <Badge variant="destructive">Rechazada</Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Emisión</p>
                      <p className="font-semibold">
                        {format(new Date(factura?.fechaEmision), 'dd/MM/yyyy', { locale: es })}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Vencimiento</p>
                      <p className="font-semibold">
                        {format(new Date(factura?.fechaVencimiento), 'dd/MM/yyyy', { locale: es })}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Forma de Pago</p>
                      <p className="font-semibold capitalize">{factura?.formaPago}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Total</p>
                      <p className="font-bold text-lg">{formatCurrency(factura?.total ?? 0)}</p>
                    </div>
                  </div>

                  {factura?.motivoRechazo && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Motivo de rechazo:</strong> {factura.motivoRechazo}
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="flex flex-wrap gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenDialog(factura)}
                      className="gap-2"
                    >
                      <Pencil className="h-3 w-3" />
                      Editar
                    </Button>
                    
                    {factura?.estado === 'pendiente' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleOpenEstadoDialog(factura)}
                        className="gap-2"
                      >
                        <CheckCircle className="h-3 w-3" />
                        Cambiar Estado
                      </Button>
                    )}

                    <Button
                      variant={factura?.estadoPago === 'pagada' ? 'secondary' : 'default'}
                      size="sm"
                      onClick={() => handleTogglePago(factura)}
                      className="gap-2"
                    >
                      {factura?.estadoPago === 'pagada' ? 'Marcar Por Pagar' : 'Marcar Pagada'}
                    </Button>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleOpenDeleteDialog(factura)}
                      className="gap-2"
                    >
                      <Trash2 className="h-3 w-3" />
                      Eliminar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Create/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>
                  {editingFactura ? 'Editar Factura' : 'Nueva Factura'}
                </DialogTitle>
                <DialogDescription>
                  {editingFactura
                    ? 'Actualiza la información de la factura'
                    : 'Ingresa los datos de la nueva factura'}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="proveedor">Proveedor *</Label>
                    <Select
                      value={formData?.proveedorId ?? ''}
                      onValueChange={(value) =>
                        setFormData({ ...formData, proveedorId: value })
                      }
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar proveedor" />
                      </SelectTrigger>
                      <SelectContent>
                        {proveedores?.map?.((p) => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.nombre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="numeroFactura">Número Factura *</Label>
                    <Input
                      id="numeroFactura"
                      value={formData?.numeroFactura ?? ''}
                      onChange={(e) =>
                        setFormData({ ...formData, numeroFactura: e.target.value })
                      }
                      placeholder="123456"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="rutEmpresa">RUT Empresa</Label>
                    <Input
                      id="rutEmpresa"
                      value={formData?.rutEmpresa ?? ''}
                      onChange={(e) =>
                        setFormData({ ...formData, rutEmpresa: e.target.value })
                      }
                      placeholder="12.345.678-9"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="nombreVendedor">Nombre Vendedor</Label>
                    <Input
                      id="nombreVendedor"
                      value={formData?.nombreVendedor ?? ''}
                      onChange={(e) =>
                        setFormData({ ...formData, nombreVendedor: e.target.value })
                      }
                      placeholder="Juan Pérez"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fechaEmision">Fecha Emisión *</Label>
                    <Input
                      id="fechaEmision"
                      type="date"
                      value={formData?.fechaEmision ?? ''}
                      onChange={(e) =>
                        setFormData({ ...formData, fechaEmision: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fechaVencimiento">Fecha Vencimiento *</Label>
                    <Input
                      id="fechaVencimiento"
                      type="date"
                      value={formData?.fechaVencimiento ?? ''}
                      onChange={(e) =>
                        setFormData({ ...formData, fechaVencimiento: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="formaPago">Forma de Pago *</Label>
                    <Select
                      value={formData?.formaPago ?? 'credito'}
                      onValueChange={(value) =>
                        setFormData({ ...formData, formaPago: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="credito">Crédito</SelectItem>
                        <SelectItem value="contado">Contado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="totalNeto">Total Neto *</Label>
                    <Input
                      id="totalNeto"
                      type="number"
                      step="0.01"
                      value={formData?.totalNeto ?? ''}
                      onChange={(e) => handleNetoChange(e.target.value)}
                      placeholder="1000000"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="iva">IVA (19%) *</Label>
                    <Input
                      id="iva"
                      type="number"
                      step="0.01"
                      value={formData?.iva ?? ''}
                      readOnly
                      className="bg-muted"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="total">Total *</Label>
                    <Input
                      id="total"
                      type="number"
                      step="0.01"
                      value={formData?.total ?? ''}
                      readOnly
                      className="bg-muted font-bold"
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleCloseDialog}
                  disabled={submitting}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Guardando...
                    </>
                  ) : editingFactura ? (
                    'Actualizar'
                  ) : (
                    'Crear'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                Confirmar Eliminación
              </DialogTitle>
              <DialogDescription>
                ¿Estás seguro de que deseas eliminar la factura N°{' '}
                <span className="font-semibold">{deletingFactura?.numeroFactura}</span>?
              </DialogDescription>
            </DialogHeader>
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Esta acción no se puede deshacer.
              </AlertDescription>
            </Alert>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleCloseDeleteDialog}
                disabled={submitting}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDelete}
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Eliminando...
                  </>
                ) : (
                  'Eliminar'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Estado Change Dialog */}
        <Dialog open={isEstadoDialogOpen} onOpenChange={setIsEstadoDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Cambiar Estado de Factura</DialogTitle>
              <DialogDescription>
                Factura N° {changingEstadoFactura?.numeroFactura}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Nuevo Estado *</Label>
                <Select value={nuevoEstado} onValueChange={setNuevoEstado}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="aceptada">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Aceptar
                      </div>
                    </SelectItem>
                    <SelectItem value="rechazada">
                      <div className="flex items-center gap-2">
                        <XCircle className="h-4 w-4 text-red-500" />
                        Rechazar
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {nuevoEstado === 'rechazada' && (
                <div className="space-y-2">
                  <Label htmlFor="motivoRechazo">Motivo de Rechazo *</Label>
                  <Textarea
                    id="motivoRechazo"
                    value={motivoRechazo}
                    onChange={(e) => setMotivoRechazo(e.target.value)}
                    placeholder="Describe el motivo del rechazo..."
                    rows={3}
                    required
                  />
                </div>
              )}
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleCloseEstadoDialog}
                disabled={submitting}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                onClick={handleChangeEstado}
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  'Confirmar'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
