'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ShoppingBag, Plus, Pencil, Trash2, Loader2, AlertTriangle, Filter, X } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface CompraSinBoleta {
  id: string;
  fechaIngreso: string;
  monto: number;
  tipoCompra: string;
  nombreProducto: string;
}

interface FormData {
  fechaIngreso: string;
  monto: string;
  tipoCompra: string;
  nombreProducto: string;
}

export default function ComprasSinBoletaContent() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const negocioActivo = useAppStore((state) => state?.negocioActivo);
  const [mounted, setMounted] = useState(false);
  const [compras, setCompras] = useState<CompraSinBoleta[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingCompra, setEditingCompra] = useState<CompraSinBoleta | null>(null);
  const [deletingCompra, setDeletingCompra] = useState<CompraSinBoleta | null>(null);
  const [formData, setFormData] = useState<FormData>({
    fechaIngreso: '',
    monto: '',
    tipoCompra: '',
    nombreProducto: ''
  });
  const [submitting, setSubmitting] = useState(false);
  
  // Filtros
  const [filters, setFilters] = useState({
    fechaInicio: '',
    fechaFin: ''
  });
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [mounted, status, router]);

  useEffect(() => {
    if (mounted && status === 'authenticated' && negocioActivo?.id) {
      fetchCompras();
    }
  }, [mounted, status, negocioActivo?.id]);

  useEffect(() => {
    if (mounted && status === 'authenticated' && negocioActivo?.id) {
      fetchCompras();
    }
  }, [filters]);

  const fetchCompras = async () => {
    if (!negocioActivo?.id) return;

    try {
      setLoading(true);
      const params = new URLSearchParams({ negocioId: negocioActivo.id });
      
      if (filters.fechaInicio) params.append('fechaInicio', filters.fechaInicio);
      if (filters.fechaFin) params.append('fechaFin', filters.fechaFin);

      const response = await fetch(`/api/compras-sin-boleta?${params.toString()}`);
      if (response.ok) {
        const data = await response.json();
        setCompras(data ?? []);
      } else {
        toast.error('Error al cargar compras sin boleta');
      }
    } catch (error) {
      console.error('Error fetching compras:', error);
      toast.error('Error al cargar compras sin boleta');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (compra?: CompraSinBoleta) => {
    if (compra) {
      setEditingCompra(compra);
      setFormData({
        fechaIngreso: format(new Date(compra.fechaIngreso), 'yyyy-MM-dd'),
        monto: compra.monto.toString(),
        tipoCompra: compra.tipoCompra,
        nombreProducto: compra.nombreProducto
      });
    } else {
      setEditingCompra(null);
      setFormData({
        fechaIngreso: format(new Date(), 'yyyy-MM-dd'),
        monto: '',
        tipoCompra: '',
        nombreProducto: ''
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingCompra(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData?.fechaIngreso || !formData?.monto || !formData?.tipoCompra || !formData?.nombreProducto) {
      toast.error('Completa todos los campos requeridos');
      return;
    }

    if (!negocioActivo?.id) {
      toast.error('Selecciona un negocio activo');
      return;
    }

    try {
      setSubmitting(true);
      const url = editingCompra ? `/api/compras-sin-boleta/${editingCompra.id}` : '/api/compras-sin-boleta';
      const method = editingCompra ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          negocioId: negocioActivo.id
        })
      });

      if (response.ok) {
        toast.success(editingCompra ? 'Compra actualizada' : 'Compra registrada');
        handleCloseDialog();
        fetchCompras();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al guardar compra');
      }
    } catch (error) {
      console.error('Error submitting:', error);
      toast.error('Error al guardar compra');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenDeleteDialog = (compra: CompraSinBoleta) => {
    setDeletingCompra(compra);
    setIsDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setIsDeleteDialogOpen(false);
    setDeletingCompra(null);
  };

  const handleDelete = async () => {
    if (!deletingCompra) return;

    try {
      setSubmitting(true);
      const response = await fetch(`/api/compras-sin-boleta/${deletingCompra.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        toast.success('Compra eliminada');
        handleCloseDeleteDialog();
        fetchCompras();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al eliminar compra');
      }
    } catch (error) {
      console.error('Error deleting:', error);
      toast.error('Error al eliminar compra');
    } finally {
      setSubmitting(false);
    }
  };

  const clearFilters = () => {
    setFilters({
      fechaInicio: '',
      fechaFin: ''
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(value);
  };

  if (!mounted || status === 'loading') {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  if (!negocioActivo?.id) {
    return (
      <DashboardLayout>
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Selecciona un negocio activo para gestionar compras sin boleta
          </AlertDescription>
        </Alert>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Compras Sin Boleta</h1>
            <p className="text-muted-foreground">Registra compras sin documentación de {negocioActivo?.nombre}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
            <Button onClick={() => handleOpenDialog()} className="gap-2">
              <Plus className="h-4 w-4" />
              Nueva Compra
            </Button>
          </div>
        </div>

        {/* Filters */}
        {showFilters && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filtros por Fecha</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Fecha Inicio</Label>
                  <Input
                    type="date"
                    value={filters.fechaInicio}
                    onChange={(e) => setFilters({ ...filters, fechaInicio: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Fecha Fin</Label>
                  <Input
                    type="date"
                    value={filters.fechaFin}
                    onChange={(e) => setFilters({ ...filters, fechaFin: e.target.value })}
                  />
                </div>
              </div>

              <Button variant="outline" onClick={clearFilters} className="gap-2">
                <X className="h-4 w-4" />
                Limpiar Filtros
              </Button>
            </CardContent>
          </Card>
        )}

        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : compras?.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <ShoppingBag className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-center mb-4">
                No hay compras sin boleta registradas
              </p>
              <Button onClick={() => handleOpenDialog()} className="gap-2">
                <Plus className="h-4 w-4" />
                Registrar Primera Compra
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {compras?.map?.((compra) => (
              <Card key={compra?.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <ShoppingBag className="h-5 w-5 text-primary" />
                      <CardTitle className="text-lg">{compra?.nombreProducto}</CardTitle>
                    </div>
                  </div>
                  <CardDescription>
                    Tipo: <span className="font-semibold">{compra?.tipoCompra}</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Fecha:</span>
                      <span className="font-semibold">
                        {format(new Date(compra?.fechaIngreso), 'dd/MM/yyyy', { locale: es })}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Monto:</span>
                      <span className="font-bold text-lg">{formatCurrency(compra?.monto ?? 0)}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenDialog(compra)}
                      className="flex-1 gap-2"
                    >
                      <Pencil className="h-3 w-3" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleOpenDeleteDialog(compra)}
                      className="flex-1 gap-2"
                    >
                      <Trash2 className="h-3 w-3" />
                      Eliminar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Create/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>
                  {editingCompra ? 'Editar Compra Sin Boleta' : 'Nueva Compra Sin Boleta'}
                </DialogTitle>
                <DialogDescription>
                  {editingCompra
                    ? 'Actualiza la información de la compra'
                    : 'Ingresa los datos de la nueva compra'}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="fechaIngreso">Fecha de Ingreso *</Label>
                  <Input
                    id="fechaIngreso"
                    type="date"
                    value={formData?.fechaIngreso ?? ''}
                    onChange={(e) =>
                      setFormData({ ...formData, fechaIngreso: e.target.value })
                    }
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="nombreProducto">Nombre del Producto *</Label>
                  <Input
                    id="nombreProducto"
                    value={formData?.nombreProducto ?? ''}
                    onChange={(e) =>
                      setFormData({ ...formData, nombreProducto: e.target.value })
                    }
                    placeholder="Ej: Papelería, Combustible, etc."
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tipoCompra">Tipo de Compra *</Label>
                  <Input
                    id="tipoCompra"
                    value={formData?.tipoCompra ?? ''}
                    onChange={(e) =>
                      setFormData({ ...formData, tipoCompra: e.target.value })
                    }
                    placeholder="Ej: Material de oficina, Servicios, etc."
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="monto">Monto *</Label>
                  <Input
                    id="monto"
                    type="number"
                    step="0.01"
                    value={formData?.monto ?? ''}
                    onChange={(e) =>
                      setFormData({ ...formData, monto: e.target.value })
                    }
                    placeholder="10000"
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleCloseDialog}
                  disabled={submitting}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Guardando...
                    </>
                  ) : editingCompra ? (
                    'Actualizar'
                  ) : (
                    'Crear'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                Confirmar Eliminación
              </DialogTitle>
              <DialogDescription>
                ¿Estás seguro de que deseas eliminar la compra de{' '}
                <span className="font-semibold">{deletingCompra?.nombreProducto}</span>?
              </DialogDescription>
            </DialogHeader>
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Esta acción no se puede deshacer.
              </AlertDescription>
            </Alert>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleCloseDeleteDialog}
                disabled={submitting}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDelete}
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Eliminando...
                  </>
                ) : (
                  'Eliminar'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
