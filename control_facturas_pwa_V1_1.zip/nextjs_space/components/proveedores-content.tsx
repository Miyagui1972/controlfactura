'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Users, Plus, Pencil, Trash2, Loader2, AlertTriangle, Search, Phone, MapPin } from 'lucide-react';
import { toast } from 'sonner';

interface Proveedor {
  id: string;
  nombre: string;
  direccion: string | null;
  telefono: string | null;
  negocioId: string;
  createdAt: string;
}

interface FormData {
  nombre: string;
  direccion: string;
  telefono: string;
}

export default function ProveedoresContent() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const negocioActivo = useAppStore((state) => state?.negocioActivo);
  const [mounted, setMounted] = useState(false);
  const [proveedores, setProveedores] = useState<Proveedor[]>([]);
  const [filteredProveedores, setFilteredProveedores] = useState<Proveedor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingProveedor, setEditingProveedor] = useState<Proveedor | null>(null);
  const [deletingProveedor, setDeletingProveedor] = useState<Proveedor | null>(null);
  const [formData, setFormData] = useState<FormData>({
    nombre: '',
    direccion: '',
    telefono: ''
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [mounted, status, router]);

  useEffect(() => {
    if (mounted && status === 'authenticated' && negocioActivo?.id) {
      fetchProveedores();
    }
  }, [mounted, status, negocioActivo?.id]);

  useEffect(() => {
    if (!searchTerm?.trim()) {
      setFilteredProveedores(proveedores ?? []);
    } else {
      const term = searchTerm.toLowerCase();
      const filtered = proveedores?.filter?.(
        (p) =>
          p?.nombre?.toLowerCase?.()?.includes?.(term) ??
          p?.direccion?.toLowerCase?.()?.includes?.(term) ??
          p?.telefono?.includes?.(term) ??
          false
      ) ?? [];
      setFilteredProveedores(filtered);
    }
  }, [searchTerm, proveedores]);

  const fetchProveedores = async () => {
    if (!negocioActivo?.id) return;

    try {
      setLoading(true);
      const response = await fetch(`/api/proveedores?negocioId=${negocioActivo.id}`);
      if (response.ok) {
        const data = await response.json();
        setProveedores(data?.proveedores ?? []);
      } else {
        toast.error('Error al cargar proveedores');
      }
    } catch (error) {
      console.error('Error fetching proveedores:', error);
      toast.error('Error al cargar proveedores');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (proveedor?: Proveedor) => {
    if (proveedor) {
      setEditingProveedor(proveedor);
      setFormData({
        nombre: proveedor.nombre ?? '',
        direccion: proveedor.direccion ?? '',
        telefono: proveedor.telefono ?? ''
      });
    } else {
      setEditingProveedor(null);
      setFormData({ nombre: '', direccion: '', telefono: '' });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingProveedor(null);
    setFormData({ nombre: '', direccion: '', telefono: '' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData?.nombre?.trim()) {
      toast.error('El nombre es requerido');
      return;
    }

    if (!negocioActivo?.id) {
      toast.error('Selecciona un negocio activo');
      return;
    }

    try {
      setSubmitting(true);
      const url = editingProveedor
        ? `/api/proveedores/${editingProveedor.id}`
        : '/api/proveedores';
      const method = editingProveedor ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          negocioId: negocioActivo.id
        })
      });

      if (response.ok) {
        toast.success(editingProveedor ? 'Proveedor actualizado' : 'Proveedor creado');
        handleCloseDialog();
        fetchProveedores();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al guardar proveedor');
      }
    } catch (error) {
      console.error('Error submitting:', error);
      toast.error('Error al guardar proveedor');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenDeleteDialog = (proveedor: Proveedor) => {
    setDeletingProveedor(proveedor);
    setIsDeleteDialogOpen(true);
  };

  const handleCloseDeleteDialog = () => {
    setIsDeleteDialogOpen(false);
    setDeletingProveedor(null);
  };

  const handleDelete = async () => {
    if (!deletingProveedor) return;

    try {
      setSubmitting(true);
      const response = await fetch(`/api/proveedores/${deletingProveedor.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        toast.success('Proveedor eliminado');
        handleCloseDeleteDialog();
        fetchProveedores();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al eliminar proveedor');
      }
    } catch (error) {
      console.error('Error deleting:', error);
      toast.error('Error al eliminar proveedor');
    } finally {
      setSubmitting(false);
    }
  };

  if (!mounted || status === 'loading') {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  if (!negocioActivo?.id) {
    return (
      <DashboardLayout>
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Selecciona un negocio activo para gestionar proveedores
          </AlertDescription>
        </Alert>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Proveedores</h1>
            <p className="text-muted-foreground">Gestiona los proveedores de {negocioActivo?.nombre}</p>
          </div>
          <Button onClick={() => handleOpenDialog()} className="gap-2">
            <Plus className="h-4 w-4" />
            Nuevo Proveedor
          </Button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Buscar proveedores por nombre, dirección o teléfono..."
            value={searchTerm ?? ''}
            onChange={(e) => setSearchTerm(e.target.value ?? '')}
            className="pl-10"
          />
        </div>

        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filteredProveedores?.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-center mb-4">
                {searchTerm ? 'No se encontraron proveedores' : 'No hay proveedores registrados'}
              </p>
              {!searchTerm && (
                <Button onClick={() => handleOpenDialog()} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Crear Primer Proveedor
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredProveedores?.map?.((proveedor) => (
              <Card key={proveedor?.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-primary" />
                      <CardTitle className="text-xl">{proveedor?.nombre}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {proveedor?.direccion && (
                    <div className="flex items-start gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <span className="text-muted-foreground">{proveedor.direccion}</span>
                    </div>
                  )}
                  {proveedor?.telefono && (
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">{proveedor.telefono}</span>
                    </div>
                  )}
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenDialog(proveedor)}
                      className="flex-1 gap-2"
                    >
                      <Pencil className="h-3 w-3" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleOpenDeleteDialog(proveedor)}
                      className="flex-1 gap-2"
                    >
                      <Trash2 className="h-3 w-3" />
                      Eliminar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Create/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <form onSubmit={handleSubmit}>
              <DialogHeader>
                <DialogTitle>
                  {editingProveedor ? 'Editar Proveedor' : 'Nuevo Proveedor'}
                </DialogTitle>
                <DialogDescription>
                  {editingProveedor
                    ? 'Actualiza la información del proveedor'
                    : 'Ingresa los datos del nuevo proveedor'}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre *</Label>
                  <Input
                    id="nombre"
                    value={formData?.nombre ?? ''}
                    onChange={(e) =>
                      setFormData({ ...formData, nombre: e.target.value ?? '' })
                    }
                    placeholder="Nombre del proveedor"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="direccion">Dirección</Label>
                  <Input
                    id="direccion"
                    value={formData?.direccion ?? ''}
                    onChange={(e) =>
                      setFormData({ ...formData, direccion: e.target.value ?? '' })
                    }
                    placeholder="Dirección del proveedor (opcional)"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefono">Teléfono</Label>
                  <Input
                    id="telefono"
                    value={formData?.telefono ?? ''}
                    onChange={(e) =>
                      setFormData({ ...formData, telefono: e.target.value ?? '' })
                    }
                    placeholder="Teléfono del proveedor (opcional)"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleCloseDialog}
                  disabled={submitting}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Guardando...
                    </>
                  ) : editingProveedor ? (
                    'Actualizar'
                  ) : (
                    'Crear'
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                Confirmar Eliminación
              </DialogTitle>
              <DialogDescription>
                ¿Estás seguro de que deseas eliminar el proveedor{' '}
                <span className="font-semibold">{deletingProveedor?.nombre}</span>?
              </DialogDescription>
            </DialogHeader>
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Esta acción no se puede deshacer. Se eliminarán también todas las
                facturas asociadas a este proveedor.
              </AlertDescription>
            </Alert>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleCloseDeleteDialog}
                disabled={submitting}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDelete}
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Eliminando...
                  </>
                ) : (
                  'Eliminar'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
