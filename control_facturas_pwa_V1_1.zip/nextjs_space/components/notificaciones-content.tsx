'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Bell, Loader2, CheckCheck, AlertCircle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface Negocio {
  id: string;
  nombre: string;
}

interface Notificacion {
  id: string;
  mensaje: string;
  tipo: string;
  leida: boolean;
  createdAt: string;
  negocio: Negocio | null;
}

export default function NotificacionesContent() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [notificaciones, setNotificaciones] = useState<Notificacion[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [mounted, status, router]);

  useEffect(() => {
    if (mounted && status === 'authenticated') {
      fetchNotificaciones();
    }
  }, [mounted, status]);

  const fetchNotificaciones = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/notificaciones');
      if (response.ok) {
        const data = await response.json();
        setNotificaciones(data ?? []);
      } else {
        toast.error('Error al cargar notificaciones');
      }
    } catch (error) {
      console.error('Error fetching notificaciones:', error);
      toast.error('Error al cargar notificaciones');
    } finally {
      setLoading(false);
    }
  };

  const handleMarcarLeida = async (id: string) => {
    try {
      const response = await fetch(`/api/notificaciones/${id}/leer`, {
        method: 'PATCH'
      });

      if (response.ok) {
        toast.success('Notificación marcada como leída');
        fetchNotificaciones();
      } else {
        const error = await response.json();
        toast.error(error?.error ?? 'Error al marcar como leída');
      }
    } catch (error) {
      console.error('Error marking as read:', error);
      toast.error('Error al marcar como leída');
    }
  };

  const getTipoIcon = (tipo: string) => {
    switch (tipo) {
      case 'alerta':
        return <AlertCircle className="h-5 w-5 text-orange-500" />;
      case 'recordatorio':
        return <Clock className="h-5 w-5 text-blue-500" />;
      default:
        return <Bell className="h-5 w-5 text-primary" />;
    }
  };

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case 'alerta':
        return 'bg-orange-100 text-orange-800';
      case 'recordatorio':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const noLeidas = notificaciones?.filter?.(n => !n?.leida)?.length ?? 0;

  if (!mounted || status === 'loading') {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Notificaciones</h1>
            <p className="text-muted-foreground">
              {noLeidas > 0 ? `Tienes ${noLeidas} notificación${noLeidas > 1 ? 'es' : ''} sin leer` : 'No tienes notificaciones sin leer'}
            </p>
          </div>
        </div>

        {/* Información sobre notificaciones web push */}
        <Alert>
          <Bell className="h-4 w-4" />
          <AlertDescription>
            Las notificaciones te alertarán sobre facturas próximas a vencer o vencidas. 
            Asegúrate de permitir las notificaciones del navegador para recibir alertas en tiempo real.
          </AlertDescription>
        </Alert>

        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : notificaciones?.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Bell className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-center">
                No tienes notificaciones
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {notificaciones?.map?.((notificacion) => (
              <Card 
                key={notificacion?.id} 
                className={`hover:shadow-lg transition-shadow ${
                  !notificacion?.leida ? 'bg-blue-50 border-blue-200' : ''
                }`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      {getTipoIcon(notificacion?.tipo ?? 'info')}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <CardTitle className="text-lg">
                            {notificacion?.mensaje}
                          </CardTitle>
                          {!notificacion?.leida && (
                            <Badge variant="default" className="text-xs">Nueva</Badge>
                          )}
                        </div>
                        <CardDescription className="space-y-1">
                          <div>
                            Fecha: <span className="font-semibold">
                              {format(new Date(notificacion?.createdAt ?? new Date()), 'dd/MM/yyyy HH:mm', { locale: es })}
                            </span>
                          </div>
                          {notificacion?.negocio && (
                            <div>
                              Negocio: <span className="font-semibold">{notificacion.negocio.nombre}</span>
                            </div>
                          )}
                          <div>
                            <Badge className={getTipoColor(notificacion?.tipo ?? 'info')}>
                              {notificacion?.tipo === 'alerta' ? 'Alerta' : notificacion?.tipo === 'recordatorio' ? 'Recordatorio' : 'Información'}
                            </Badge>
                          </div>
                        </CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                {!notificacion?.leida && (
                  <CardContent>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleMarcarLeida(notificacion.id)}
                      className="gap-2"
                    >
                      <CheckCheck className="h-4 w-4" />
                      Marcar como leída
                    </Button>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
