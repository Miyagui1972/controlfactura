'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { ClipboardList, Filter, X, Loader2, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface Negocio {
  id: string;
  nombre: string;
}

interface User {
  id: string;
  name: string | null;
  email: string;
}

interface RegistroAuditoria {
  id: string;
  tipoRegistro: string;
  datosEliminados: string;
  fechaEliminacion: string;
  negocio: Negocio | null;
  user: User;
}

export default function AuditoriaContent() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [registros, setRegistros] = useState<RegistroAuditoria[]>([]);
  const [negocios, setNegocios] = useState<Negocio[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  
  // Filtros
  const [filters, setFilters] = useState({
    tipoRegistro: 'all',
    negocioId: 'all',
    fechaInicio: '',
    fechaFin: ''
  });

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [mounted, status, router]);

  useEffect(() => {
    if (mounted && status === 'authenticated') {
      fetchNegocios();
      fetchRegistros();
    }
  }, [mounted, status]);

  useEffect(() => {
    if (mounted && status === 'authenticated') {
      fetchRegistros();
    }
  }, [filters]);

  const fetchNegocios = async () => {
    try {
      const response = await fetch('/api/negocios');
      if (response.ok) {
        const data = await response.json();
        setNegocios(data?.negocios ?? []);
      }
    } catch (error) {
      console.error('Error fetching negocios:', error);
    }
  };

  const fetchRegistros = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      
      if (filters.tipoRegistro && filters.tipoRegistro !== 'all') params.append('tipoRegistro', filters.tipoRegistro);
      if (filters.negocioId && filters.negocioId !== 'all') params.append('negocioId', filters.negocioId);
      if (filters.fechaInicio) params.append('fechaInicio', filters.fechaInicio);
      if (filters.fechaFin) params.append('fechaFin', filters.fechaFin);

      const response = await fetch(`/api/auditoria?${params.toString()}`);
      if (response.ok) {
        const data = await response.json();
        setRegistros(data ?? []);
      } else {
        toast.error('Error al cargar registros de auditoría');
      }
    } catch (error) {
      console.error('Error fetching auditoria:', error);
      toast.error('Error al cargar registros de auditoría');
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setFilters({
      tipoRegistro: 'all',
      negocioId: 'all',
      fechaInicio: '',
      fechaFin: ''
    });
  };

  const formatJSON = (jsonString: string) => {
    try {
      const obj = JSON.parse(jsonString);
      return JSON.stringify(obj, null, 2);
    } catch (e) {
      return jsonString;
    }
  };

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case 'Negocio':
        return 'bg-blue-100 text-blue-800';
      case 'Proveedor':
        return 'bg-green-100 text-green-800';
      case 'Factura':
        return 'bg-purple-100 text-purple-800';
      case 'CompraSinBoleta':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (!mounted || status === 'loading') {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Auditoría</h1>
            <p className="text-muted-foreground">Historial de registros eliminados</p>
          </div>
          <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="gap-2">
            <Filter className="h-4 w-4" />
            Filtros
          </Button>
        </div>

        {/* Filters */}
        {showFilters && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filtros</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-2">
                  <Label>Tipo de Registro</Label>
                  <Select
                    value={filters.tipoRegistro}
                    onValueChange={(value) => setFilters({ ...filters, tipoRegistro: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="Negocio">Negocio</SelectItem>
                      <SelectItem value="Proveedor">Proveedor</SelectItem>
                      <SelectItem value="Factura">Factura</SelectItem>
                      <SelectItem value="CompraSinBoleta">Compra Sin Boleta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Negocio</Label>
                  <Select
                    value={filters.negocioId}
                    onValueChange={(value) => setFilters({ ...filters, negocioId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      {negocios?.map?.((n) => (
                        <SelectItem key={n.id} value={n.id}>
                          {n.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Fecha Inicio</Label>
                  <Input
                    type="date"
                    value={filters.fechaInicio}
                    onChange={(e) => setFilters({ ...filters, fechaInicio: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Fecha Fin</Label>
                  <Input
                    type="date"
                    value={filters.fechaFin}
                    onChange={(e) => setFilters({ ...filters, fechaFin: e.target.value })}
                  />
                </div>
              </div>

              <Button variant="outline" onClick={clearFilters} className="gap-2">
                <X className="h-4 w-4" />
                Limpiar Filtros
              </Button>
            </CardContent>
          </Card>
        )}

        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : registros?.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <ClipboardList className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-center">
                No hay registros de auditoría
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {registros?.map?.((registro) => (
              <Card key={registro?.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <ClipboardList className="h-5 w-5 text-primary" />
                        <CardTitle className="text-xl">
                          Registro Eliminado
                        </CardTitle>
                        <Badge className={getTipoColor(registro?.tipoRegistro ?? '')}>
                          {registro?.tipoRegistro}
                        </Badge>
                      </div>
                      <CardDescription className="space-y-1">
                        <div>
                          Eliminado por: <span className="font-semibold">{registro?.user?.name ?? registro?.user?.email} ({registro?.user?.email})</span>
                        </div>
                        <div>
                          Fecha: <span className="font-semibold">
                            {format(new Date(registro?.fechaEliminacion), 'dd/MM/yyyy HH:mm:ss', { locale: es })}
                          </span>
                        </div>
                        {registro?.negocio && (
                          <div>
                            Negocio: <span className="font-semibold">{registro.negocio.nombre}</span>
                          </div>
                        )}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold">Datos del Registro Eliminado:</Label>
                    <pre className="bg-muted p-4 rounded-lg text-xs overflow-x-auto">
                      <code>{formatJSON(registro?.datosEliminados ?? '{}')}</code>
                    </pre>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
