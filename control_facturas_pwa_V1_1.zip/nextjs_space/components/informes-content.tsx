'use client';

import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useAppStore } from '@/lib/store';
import { DashboardLayout } from '@/components/dashboard-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { BarChart3, Download, Loader2, AlertTriangle, FileText, DollarSign, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface Proveedor {
  id: string;
  nombre: string;
}

interface Factura {
  id: string;
  numeroFactura: string;
  total: number;
  fechaEmision: string;
  estadoPago: string;
  proveedor: {
    nombre: string;
  };
}

interface Estadisticas {
  totalFacturas: number;
  facturasPagadas: number;
  facturasPorPagar: number;
  montoTotal: number;
  montoPagado: number;
  montoPorPagar: number;
}

interface DatoProveedor {
  id: string;
  nombre: string;
  cantidad: number;
  monto: number;
}

interface DatoMes {
  mes: string;
  cantidad: number;
  monto: number;
}

export default function InformesContent() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const negocioActivo = useAppStore((state) => state?.negocioActivo);
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [proveedores, setProveedores] = useState<Proveedor[]>([]);
  const [estadisticas, setEstadisticas] = useState<Estadisticas | null>(null);
  const [datosPorProveedor, setDatosPorProveedor] = useState<DatoProveedor[]>([]);
  const [datosPorMes, setDatosPorMes] = useState<DatoMes[]>([]);
  const [facturas, setFacturas] = useState<Factura[]>([]);
  
  const lineChartRef = useRef<any>(null);
  const barChartRef = useRef<any>(null);

  // Filtros
  const [filters, setFilters] = useState({
    proveedorId: 'all',
    periodo: 'mes',
    fecha: format(new Date(), 'yyyy-MM-dd')
  });

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && status === 'unauthenticated') {
      router.replace('/login');
    }
  }, [mounted, status, router]);

  useEffect(() => {
    if (mounted && status === 'authenticated' && negocioActivo?.id) {
      fetchProveedores();
    }
  }, [mounted, status, negocioActivo?.id]);

  useEffect(() => {
    if (mounted && status === 'authenticated' && negocioActivo?.id) {
      fetchInformes();
    }
  }, [mounted, status, negocioActivo?.id, filters]);

  const fetchProveedores = async () => {
    if (!negocioActivo?.id) return;

    try {
      const response = await fetch(`/api/proveedores?negocioId=${negocioActivo.id}`);
      if (response.ok) {
        const data = await response.json();
        setProveedores(data?.proveedores ?? []);
      }
    } catch (error) {
      console.error('Error fetching proveedores:', error);
    }
  };

  const fetchInformes = async () => {
    if (!negocioActivo?.id) return;

    try {
      setLoading(true);
      const params = new URLSearchParams({
        negocioId: negocioActivo.id,
        periodo: filters.periodo,
        fecha: filters.fecha
      });
      
      if (filters.proveedorId && filters.proveedorId !== 'all') {
        params.append('proveedorId', filters.proveedorId);
      }

      const response = await fetch(`/api/informes?${params.toString()}`);
      if (response.ok) {
        const data = await response.json();
        setEstadisticas(data?.estadisticas ?? null);
        setDatosPorProveedor(data?.datosPorProveedor ?? []);
        setDatosPorMes(data?.datosPorMes ?? []);
        setFacturas(data?.facturas ?? []);
      } else {
        toast.error('Error al cargar informes');
      }
    } catch (error) {
      console.error('Error fetching informes:', error);
      toast.error('Error al cargar informes');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP' }).format(value ?? 0);
  };

  const exportToPDF = async () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      
      // Title
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('Informe de Facturas', pageWidth / 2, 15, { align: 'center' });
      
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.text(`Negocio: ${negocioActivo?.nombre ?? ''}`, 14, 25);
      doc.text(`Periodo: ${filters.periodo}`, 14, 32);
      doc.text(`Fecha: ${format(new Date(filters.fecha), 'dd/MM/yyyy', { locale: es })}`, 14, 39);
      doc.text(`Generado: ${format(new Date(), 'dd/MM/yyyy HH:mm', { locale: es })}`, 14, 46);

      // Estadísticas
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('Estadísticas', 14, 58);
      
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      let yPos = 65;
      
      doc.text(`Total de Facturas: ${estadisticas?.totalFacturas ?? 0}`, 14, yPos);
      yPos += 6;
      doc.text(`Facturas Pagadas: ${estadisticas?.facturasPagadas ?? 0}`, 14, yPos);
      yPos += 6;
      doc.text(`Facturas Por Pagar: ${estadisticas?.facturasPorPagar ?? 0}`, 14, yPos);
      yPos += 6;
      doc.text(`Monto Total: ${formatCurrency(estadisticas?.montoTotal ?? 0)}`, 14, yPos);
      yPos += 6;
      doc.text(`Monto Pagado: ${formatCurrency(estadisticas?.montoPagado ?? 0)}`, 14, yPos);
      yPos += 6;
      doc.text(`Monto Por Pagar: ${formatCurrency(estadisticas?.montoPorPagar ?? 0)}`, 14, yPos);
      yPos += 10;

      // Datos por proveedor
      if (datosPorProveedor?.length > 0) {
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.text('Datos por Proveedor', 14, yPos);
        yPos += 7;

        autoTable(doc, {
          startY: yPos,
          head: [['Proveedor', 'Cantidad', 'Monto Total']],
          body: datosPorProveedor.map((p: DatoProveedor) => [
            p?.nombre ?? '',
            p?.cantidad?.toString() ?? '0',
            formatCurrency(p?.monto ?? 0)
          ]),
          styles: { fontSize: 9 },
          headStyles: { fillColor: [37, 99, 235] }
        });

        yPos = (doc as any).lastAutoTable.finalY + 10;
      }

      // Nueva página para la tabla de facturas
      doc.addPage();
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text('Detalle de Facturas', 14, 15);

      if (facturas?.length > 0) {
        autoTable(doc, {
          startY: 22,
          head: [['N° Factura', 'Proveedor', 'Fecha', 'Total', 'Estado']],
          body: facturas.map((f: Factura) => [
            f?.numeroFactura ?? '',
            f?.proveedor?.nombre ?? '',
            format(new Date(f?.fechaEmision ?? new Date()), 'dd/MM/yyyy', { locale: es }),
            formatCurrency(f?.total ?? 0),
            f?.estadoPago === 'pagada' ? 'Pagada' : 'Por Pagar'
          ]),
          styles: { fontSize: 8 },
          headStyles: { fillColor: [37, 99, 235] }
        });
      }

      // Save PDF
      const fileName = `Informe_Facturas_${format(new Date(), 'yyyyMMdd_HHmmss')}.pdf`;
      doc.save(fileName);
      toast.success('PDF generado correctamente');
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error('Error al generar PDF');
    }
  };

  if (!mounted || status === 'loading') {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  if (!negocioActivo?.id) {
    return (
      <DashboardLayout>
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Selecciona un negocio activo para ver informes
          </AlertDescription>
        </Alert>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Informes</h1>
            <p className="text-muted-foreground">Análisis y estadísticas de {negocioActivo?.nombre}</p>
          </div>
          <Button onClick={exportToPDF} className="gap-2" disabled={loading || !estadisticas}>
            <Download className="h-4 w-4" />
            Exportar a PDF
          </Button>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Filtros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label>Periodo</Label>
                <Select
                  value={filters.periodo}
                  onValueChange={(value) => setFilters({ ...filters, periodo: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dia">Día</SelectItem>
                    <SelectItem value="semana">Semana</SelectItem>
                    <SelectItem value="mes">Mes</SelectItem>
                    <SelectItem value="ano">Año</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Fecha de Referencia</Label>
                <Input
                  type="date"
                  value={filters.fecha}
                  onChange={(e) => setFilters({ ...filters, fecha: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Proveedor</Label>
                <Select
                  value={filters.proveedorId}
                  onValueChange={(value) => setFilters({ ...filters, proveedorId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    {proveedores?.map?.((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex items-center justify-center min-h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Estadísticas */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Facturas</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{estadisticas?.totalFacturas ?? 0}</div>
                  <div className="flex items-center gap-2 mt-2 text-sm">
                    <Badge variant="default" className="gap-1">
                      <CheckCircle className="h-3 w-3" />
                      {estadisticas?.facturasPagadas ?? 0} Pagadas
                    </Badge>
                    <Badge variant="secondary" className="gap-1">
                      <XCircle className="h-3 w-3" />
                      {estadisticas?.facturasPorPagar ?? 0} Por Pagar
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monto Total</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(estadisticas?.montoTotal ?? 0)}</div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Total de todas las facturas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monto Pagado</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">
                    {formatCurrency(estadisticas?.montoPagado ?? 0)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Total de facturas pagadas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monto Por Pagar</CardTitle>
                  <XCircle className="h-4 w-4 text-orange-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">
                    {formatCurrency(estadisticas?.montoPorPagar ?? 0)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Total de facturas por pagar
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Gráficos */}
            {datosPorMes?.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Facturas por Mes</CardTitle>
                  <CardDescription>Evolución temporal de facturas y montos</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={datosPorMes} ref={lineChartRef}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="mes" 
                        tick={{ fontSize: 11 }}
                        tickLine={false}
                      />
                      <YAxis 
                        yAxisId="left"
                        tick={{ fontSize: 11 }}
                        tickLine={false}
                        label={{ value: 'Cantidad', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }}
                      />
                      <YAxis 
                        yAxisId="right"
                        orientation="right"
                        tick={{ fontSize: 11 }}
                        tickLine={false}
                        label={{ value: 'Monto', angle: 90, position: 'insideRight', style: { fontSize: 11 } }}
                      />
                      <Tooltip 
                        contentStyle={{ fontSize: 11 }}
                        formatter={(value: any, name: string) => {
                          if (name === 'monto') {
                            return formatCurrency(Number(value));
                          }
                          return value;
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Line 
                        yAxisId="left"
                        type="monotone" 
                        dataKey="cantidad" 
                        stroke="#60B5FF" 
                        strokeWidth={2}
                        name="Cantidad"
                      />
                      <Line 
                        yAxisId="right"
                        type="monotone" 
                        dataKey="monto" 
                        stroke="#FF9149" 
                        strokeWidth={2}
                        name="Monto"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {datosPorProveedor?.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Montos por Proveedor</CardTitle>
                  <CardDescription>Comparación de montos totales por proveedor</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={datosPorProveedor} ref={barChartRef}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="nombre" 
                        tick={{ fontSize: 10 }}
                        angle={-45}
                        textAnchor="end"
                        height={80}
                        tickLine={false}
                      />
                      <YAxis 
                        tick={{ fontSize: 11 }}
                        tickLine={false}
                        label={{ value: 'Monto', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }}
                      />
                      <Tooltip 
                        contentStyle={{ fontSize: 11 }}
                        formatter={(value: any) => formatCurrency(Number(value))}
                      />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Bar dataKey="monto" fill="#60B5FF" name="Monto Total" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {/* Tabla de Facturas */}
            {facturas?.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Detalle de Facturas</CardTitle>
                  <CardDescription>Listado completo de facturas del periodo</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4">N° Factura</th>
                          <th className="text-left py-3 px-4">Proveedor</th>
                          <th className="text-left py-3 px-4">Fecha Emisión</th>
                          <th className="text-right py-3 px-4">Total</th>
                          <th className="text-center py-3 px-4">Estado Pago</th>
                        </tr>
                      </thead>
                      <tbody>
                        {facturas?.map?.((factura) => (
                          <tr key={factura?.id} className="border-b hover:bg-muted/50">
                            <td className="py-3 px-4 font-medium">{factura?.numeroFactura}</td>
                            <td className="py-3 px-4">{factura?.proveedor?.nombre}</td>
                            <td className="py-3 px-4">
                              {format(new Date(factura?.fechaEmision ?? new Date()), 'dd/MM/yyyy', { locale: es })}
                            </td>
                            <td className="py-3 px-4 text-right font-semibold">
                              {formatCurrency(factura?.total ?? 0)}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <Badge variant={factura?.estadoPago === 'pagada' ? 'default' : 'secondary'}>
                                {factura?.estadoPago === 'pagada' ? 'Pagada' : 'Por Pagar'}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )}

            {!estadisticas && !loading && (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground text-center">
                    No hay datos para mostrar en el periodo seleccionado
                  </p>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
