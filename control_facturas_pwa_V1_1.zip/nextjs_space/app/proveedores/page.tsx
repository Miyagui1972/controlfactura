'use client';

import { AuthGuard } from '@/components/auth-guard';
import ProveedoresContent from '@/components/proveedores-content';

export default function ProveedoresPage() {
  return (
    <AuthGuard>
      <ProveedoresContent />
    </AuthGuard>
  );
}
