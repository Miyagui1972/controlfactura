'use client';

import { AuthGuard } from '@/components/auth-guard';
import NotificacionesContent from '@/components/notificaciones-content';

export default function NotificacionesPage() {
  return (
    <AuthGuard>
      <NotificacionesContent />
    </AuthGuard>
  );
}
