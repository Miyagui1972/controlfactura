'use client';

import { AuthGuard } from '@/components/auth-guard';
import NegociosContent from '@/components/negocios-content';

export default function NegociosPage() {
  return (
    <AuthGuard>
      <NegociosContent />
    </AuthGuard>
  );
}
