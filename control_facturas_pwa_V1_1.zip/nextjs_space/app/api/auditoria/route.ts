import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET: Listar registros de auditoría
export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const tipoRegistro = searchParams.get('tipoRegistro');
    const negocioId = searchParams.get('negocioId');
    const fechaInicio = searchParams.get('fechaInicio');
    const fechaFin = searchParams.get('fechaFin');

    // Construir filtros
    const where: any = {
      userId: session.user.id
    };
    
    if (tipoRegistro) {
      where.tipoRegistro = tipoRegistro;
    }
    
    if (negocioId) {
      where.negocioId = negocioId;
    }
    
    if (fechaInicio || fechaFin) {
      where.fechaEliminacion = {};
      if (fechaInicio) {
        where.fechaEliminacion.gte = new Date(fechaInicio);
      }
      if (fechaFin) {
        where.fechaEliminacion.lte = new Date(fechaFin);
      }
    }

    const registros = await prisma.auditoria.findMany({
      where,
      include: {
        negocio: {
          select: {
            id: true,
            nombre: true
          }
        },
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      },
      orderBy: {
        fechaEliminacion: 'desc'
      }
    });

    return NextResponse.json(registros);
  } catch (error) {
    console.error('Error fetching auditoria:', error);
    return NextResponse.json(
      { error: 'Error al obtener registros de auditoría' },
      { status: 500 }
    );
  }
}
