import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const negocioId = searchParams.get('negocioId');

    if (!negocioId) {
      return NextResponse.json(
        { error: 'ID de negocio requerido' },
        { status: 400 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    const negocio = await prisma.negocio.findFirst({
      where: {
        id: negocioId,
        userId: session.user.id,
      },
    });

    if (!negocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    // Obtener todas las facturas del negocio
    const facturas = await prisma.factura.findMany({
      where: { negocioId },
    });

    // Calcular estadísticas
    const totalFacturas = facturas?.length || 0;
    const facturasAceptadas = facturas?.filter((f: any) => f?.estado === 'Aceptada')?.length || 0;
    const facturasPendientes = facturas?.filter((f: any) => f?.estado === 'Pendiente')?.length || 0;
    const facturasRechazadas = facturas?.filter((f: any) => f?.estado === 'Rechazada')?.length || 0;
    const facturasPagadas = facturas?.filter((f: any) => f?.estadoPago === 'Pagada')?.length || 0;
    const facturasPorPagar = facturas?.filter((f: any) => f?.estadoPago === 'Por pagar')?.length || 0;

    const montoTotal = facturas?.reduce((sum: number, f: any) => sum + (f?.total || 0), 0) || 0;
    const montoPagado = facturas
      ?.filter((f: any) => f?.estadoPago === 'Pagada')
      ?.reduce((sum: number, f: any) => sum + (f?.total || 0), 0) || 0;
    const montoPorPagar = facturas
      ?.filter((f: any) => f?.estadoPago === 'Por pagar')
      ?.reduce((sum: number, f: any) => sum + (f?.total || 0), 0) || 0;

    // Facturas próximas a vencer (7 días)
    const today = new Date();
    const sevenDaysLater = new Date();
    sevenDaysLater.setDate(today.getDate() + 7);

    const facturasProximasVencer = facturas?.filter((f: any) => {
      if (f?.estadoPago !== 'Por pagar') return false;
      const vencimiento = new Date(f?.fechaVencimiento || '');
      return vencimiento >= today && vencimiento <= sevenDaysLater;
    })?.length || 0;

    const stats = {
      totalFacturas,
      facturasAceptadas,
      facturasPendientes,
      facturasRechazadas,
      facturasPagadas,
      facturasPorPagar,
      montoTotal,
      montoPagado,
      montoPorPagar,
      facturasProximasVencer,
    };

    return NextResponse.json({ stats });
  } catch (error) {
    console.error('Error al obtener estadísticas:', error);
    return NextResponse.json(
      { error: 'Error al obtener estadísticas' },
      { status: 500 }
    );
  }
}
