import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// PUT: Editar compra sin boleta
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { id } = params;
    const body = await request.json();
    const {
      fechaIngreso,
      monto,
      tipoCompra,
      nombreProducto
    } = body;

    if (!fechaIngreso || !monto || !tipoCompra || !nombreProducto) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' },
        { status: 400 }
      );
    }

    // Verificar que la compra existe
    const compraExistente = await prisma.compraSinBoleta.findUnique({
      where: { id },
      include: {
        negocio: true
      }
    });

    if (!compraExistente) {
      return NextResponse.json(
        { error: 'Compra no encontrada' },
        { status: 404 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    if (compraExistente.negocio.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    const compra = await prisma.compraSinBoleta.update({
      where: { id },
      data: {
        fechaIngreso: new Date(fechaIngreso),
        monto: parseFloat(monto),
        tipoCompra,
        nombreProducto
      }
    });

    return NextResponse.json(compra);
  } catch (error) {
    console.error('Error updating compra sin boleta:', error);
    return NextResponse.json(
      { error: 'Error al actualizar compra sin boleta' },
      { status: 500 }
    );
  }
}

// DELETE: Eliminar compra sin boleta
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { id } = params;

    // Obtener la compra
    const compra = await prisma.compraSinBoleta.findUnique({
      where: { id },
      include: {
        negocio: true
      }
    });

    if (!compra) {
      return NextResponse.json(
        { error: 'Compra no encontrada' },
        { status: 404 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    if (compra.negocio.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    // Registrar en auditoría
    await prisma.auditoria.create({
      data: {
        userId: session.user.id,
        tipoRegistro: 'CompraSinBoleta',
        datosEliminados: JSON.stringify({
          id: compra.id,
          nombreProducto: compra.nombreProducto,
          tipoCompra: compra.tipoCompra,
          monto: compra.monto,
          fechaIngreso: compra.fechaIngreso
        }),
        negocioId: compra.negocioId
      }
    });

    // Eliminar compra
    await prisma.compraSinBoleta.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting compra sin boleta:', error);
    return NextResponse.json(
      { error: 'Error al eliminar compra sin boleta' },
      { status: 500 }
    );
  }
}
