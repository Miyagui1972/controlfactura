import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET: Listar compras sin boleta
export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const negocioId = searchParams.get('negocioId');
    const fechaInicio = searchParams.get('fechaInicio');
    const fechaFin = searchParams.get('fechaFin');

    if (!negocioId) {
      return NextResponse.json(
        { error: 'negocioId es requerido' },
        { status: 400 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    const negocio = await prisma.negocio.findFirst({
      where: {
        id: negocioId,
        userId: session.user.id
      }
    });

    if (!negocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    // Construir filtros
    const where: any = { negocioId };
    
    if (fechaInicio || fechaFin) {
      where.fechaIngreso = {};
      if (fechaInicio) {
        where.fechaIngreso.gte = new Date(fechaInicio);
      }
      if (fechaFin) {
        where.fechaIngreso.lte = new Date(fechaFin);
      }
    }

    const compras = await prisma.compraSinBoleta.findMany({
      where,
      orderBy: {
        fechaIngreso: 'desc'
      }
    });

    return NextResponse.json(compras);
  } catch (error) {
    console.error('Error fetching compras sin boleta:', error);
    return NextResponse.json(
      { error: 'Error al obtener compras sin boleta' },
      { status: 500 }
    );
  }
}

// POST: Crear compra sin boleta
export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      negocioId,
      fechaIngreso,
      monto,
      tipoCompra,
      nombreProducto
    } = body;

    if (!negocioId || !fechaIngreso || !monto || !tipoCompra || !nombreProducto) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' },
        { status: 400 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    const negocio = await prisma.negocio.findFirst({
      where: {
        id: negocioId,
        userId: session.user.id
      }
    });

    if (!negocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    const compra = await prisma.compraSinBoleta.create({
      data: {
        negocioId,
        fechaIngreso: new Date(fechaIngreso),
        monto: parseFloat(monto),
        tipoCompra,
        nombreProducto
      }
    });

    return NextResponse.json(compra, { status: 201 });
  } catch (error) {
    console.error('Error creating compra sin boleta:', error);
    return NextResponse.json(
      { error: 'Error al crear compra sin boleta' },
      { status: 500 }
    );
  }
}
