import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const negocioId = searchParams.get('negocioId');

    if (!negocioId) {
      return NextResponse.json(
        { error: 'ID de negocio requerido' },
        { status: 400 }
      );
    }

    const proveedores = await prisma.proveedor.findMany({
      where: { negocioId },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ proveedores });
  } catch (error) {
    console.error('Error al obtener proveedores:', error);
    return NextResponse.json(
      { error: 'Error al obtener proveedores' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { negocioId, nombre, direccion, telefono } = body;

    if (!negocioId || !nombre) {
      return NextResponse.json(
        { error: 'Negocio y nombre son requeridos' },
        { status: 400 }
      );
    }

    const proveedor = await prisma.proveedor.create({
      data: {
        negocioId,
        nombre,
        direccion: direccion || null,
        telefono: telefono || null,
      },
    });

    return NextResponse.json({ proveedor }, { status: 201 });
  } catch (error) {
    console.error('Error al crear proveedor:', error);
    return NextResponse.json(
      { error: 'Error al crear proveedor' },
      { status: 500 }
    );
  }
}
