import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const { nombre, direccion, telefono } = body;

    if (!nombre) {
      return NextResponse.json(
        { error: 'El nombre es requerido' },
        { status: 400 }
      );
    }

    const proveedor = await prisma.proveedor.update({
      where: { id },
      data: {
        nombre,
        direccion: direccion || null,
        telefono: telefono || null,
      },
    });

    return NextResponse.json({ proveedor });
  } catch (error) {
    console.error('Error al actualizar proveedor:', error);
    return NextResponse.json(
      { error: 'Error al actualizar proveedor' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    const proveedor = await prisma.proveedor.findUnique({
      where: { id },
      include: { negocio: true },
    });

    if (!proveedor) {
      return NextResponse.json(
        { error: 'Proveedor no encontrado' },
        { status: 404 }
      );
    }

    // Registrar eliminación en auditoría
    await prisma.auditoria.create({
      data: {
        userId: session.user.id,
        negocioId: proveedor.negocioId,
        tipoRegistro: 'Proveedor',
        datosEliminados: JSON.stringify({
          nombre: proveedor.nombre,
          direccion: proveedor.direccion,
          telefono: proveedor.telefono,
        }),
      },
    });

    await prisma.proveedor.delete({
      where: { id },
    });

    return NextResponse.json({ message: 'Proveedor eliminado exitosamente' });
  } catch (error) {
    console.error('Error al eliminar proveedor:', error);
    return NextResponse.json(
      { error: 'Error al eliminar proveedor' },
      { status: 500 }
    );
  }
}
