import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET: Obtener datos para informes
export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const negocioId = searchParams.get('negocioId');
    const proveedorId = searchParams.get('proveedorId');
    const periodo = searchParams.get('periodo'); // dia, semana, mes, ano
    const fecha = searchParams.get('fecha'); // fecha especifica o referencia

    if (!negocioId) {
      return NextResponse.json(
        { error: 'negocioId es requerido' },
        { status: 400 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    const negocio = await prisma.negocio.findFirst({
      where: {
        id: negocioId,
        userId: session.user.id
      }
    });

    if (!negocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    // Calcular rango de fechas según periodo
    let fechaInicio: Date | undefined;
    let fechaFin: Date | undefined;
    const now = fecha ? new Date(fecha) : new Date();

    if (periodo === 'dia') {
      fechaInicio = new Date(now.setHours(0, 0, 0, 0));
      fechaFin = new Date(now.setHours(23, 59, 59, 999));
    } else if (periodo === 'semana') {
      const dayOfWeek = now.getDay();
      fechaInicio = new Date(now);
      fechaInicio.setDate(now.getDate() - dayOfWeek);
      fechaInicio.setHours(0, 0, 0, 0);
      fechaFin = new Date(fechaInicio);
      fechaFin.setDate(fechaInicio.getDate() + 6);
      fechaFin.setHours(23, 59, 59, 999);
    } else if (periodo === 'mes') {
      fechaInicio = new Date(now.getFullYear(), now.getMonth(), 1);
      fechaFin = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    } else if (periodo === 'ano') {
      fechaInicio = new Date(now.getFullYear(), 0, 1);
      fechaFin = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
    }

    // Construir filtros
    const where: any = { negocioId };
    
    if (proveedorId) {
      where.proveedorId = proveedorId;
    }
    
    if (fechaInicio && fechaFin) {
      where.fechaEmision = {
        gte: fechaInicio,
        lte: fechaFin
      };
    }

    // Obtener facturas con relaciones
    const facturas = await prisma.factura.findMany({
      where,
      include: {
        proveedor: {
          select: {
            id: true,
            nombre: true
          }
        }
      },
      orderBy: {
        fechaEmision: 'asc'
      }
    });

    // Calcular estadísticas
    const totalFacturas = facturas.length;
    const facturasPagadas = facturas.filter((f: any) => f.estadoPago === 'pagada').length;
    const facturasPorPagar = facturas.filter((f: any) => f.estadoPago === 'porPagar').length;
    
    const montoTotal = facturas.reduce((sum: number, f: any) => sum + Number(f.total), 0);
    const montoPagado = facturas.filter((f: any) => f.estadoPago === 'pagada').reduce((sum: number, f: any) => sum + Number(f.total), 0);
    const montoPorPagar = facturas.filter((f: any) => f.estadoPago === 'porPagar').reduce((sum: number, f: any) => sum + Number(f.total), 0);

    // Agrupar por proveedor
    const porProveedor = facturas.reduce((acc: any, factura: any) => {
      const proveedorId = factura.proveedor.id;
      const proveedorNombre = factura.proveedor.nombre;
      
      if (!acc[proveedorId]) {
        acc[proveedorId] = {
          id: proveedorId,
          nombre: proveedorNombre,
          cantidad: 0,
          monto: 0
        };
      }
      
      acc[proveedorId].cantidad += 1;
      acc[proveedorId].monto += Number(factura.total);
      
      return acc;
    }, {});

    const datosPorProveedor = Object.values(porProveedor);

    // Agrupar por mes (para gráfico de línea temporal)
    const porMes = facturas.reduce((acc: any, factura: any) => {
      const fecha = new Date(factura.fechaEmision);
      const mes = `${fecha.getFullYear()}-${String(fecha.getMonth() + 1).padStart(2, '0')}`;
      
      if (!acc[mes]) {
        acc[mes] = {
          mes,
          cantidad: 0,
          monto: 0
        };
      }
      
      acc[mes].cantidad += 1;
      acc[mes].monto += Number(factura.total);
      
      return acc;
    }, {});

    const datosPorMes = Object.values(porMes).sort((a: any, b: any) => a.mes.localeCompare(b.mes));

    return NextResponse.json({
      estadisticas: {
        totalFacturas,
        facturasPagadas,
        facturasPorPagar,
        montoTotal,
        montoPagado,
        montoPorPagar
      },
      datosPorProveedor,
      datosPorMes,
      facturas
    });
  } catch (error) {
    console.error('Error fetching informes:', error);
    return NextResponse.json(
      { error: 'Error al obtener datos de informes' },
      { status: 500 }
    );
  }
}
