import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const { nombre, descripcion } = body;

    if (!nombre) {
      return NextResponse.json(
        { error: 'El nombre del negocio es requerido' },
        { status: 400 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    const existingNegocio = await prisma.negocio.findFirst({
      where: {
        id,
        userId: session.user.id,
      },
    });

    if (!existingNegocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    const negocio = await prisma.negocio.update({
      where: { id },
      data: {
        nombre,
        descripcion: descripcion || null,
      },
    });

    return NextResponse.json({ negocio });
  } catch (error) {
    console.error('Error al actualizar negocio:', error);
    return NextResponse.json(
      { error: 'Error al actualizar negocio' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    // Verificar que el negocio pertenece al usuario
    const negocio = await prisma.negocio.findFirst({
      where: {
        id,
        userId: session.user.id,
      },
    });

    if (!negocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    // Registrar eliminación en auditoría
    await prisma.auditoria.create({
      data: {
        userId: session.user.id,
        negocioId: id,
        tipoRegistro: 'Negocio',
        datosEliminados: JSON.stringify({
          nombre: negocio.nombre,
          descripcion: negocio.descripcion,
        }),
      },
    });

    // Eliminar negocio (cascade eliminará proveedores, facturas, etc.)
    await prisma.negocio.delete({
      where: { id },
    });

    return NextResponse.json({ message: 'Negocio eliminado exitosamente' });
  } catch (error) {
    console.error('Error al eliminar negocio:', error);
    return NextResponse.json(
      { error: 'Error al eliminar negocio' },
      { status: 500 }
    );
  }
}
