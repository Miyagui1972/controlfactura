import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// PATCH: Cambiar estado de factura (aceptar/rechazar)
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { id } = params;
    const body = await request.json();
    const { estado, motivoRechazo } = body;

    if (!estado || !['aceptada', 'rechazada'].includes(estado)) {
      return NextResponse.json(
        { error: 'Estado inválido. Debe ser "aceptada" o "rechazada"' },
        { status: 400 }
      );
    }

    if (estado === 'rechazada' && !motivoRechazo) {
      return NextResponse.json(
        { error: 'El motivo de rechazo es requerido' },
        { status: 400 }
      );
    }

    // Verificar que la factura existe
    const facturaExistente = await prisma.factura.findUnique({
      where: { id },
      include: {
        negocio: true
      }
    });

    if (!facturaExistente) {
      return NextResponse.json(
        { error: 'Factura no encontrada' },
        { status: 404 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    if (facturaExistente.negocio.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    const updateData: any = {
      estado
    };

    if (estado === 'aceptada') {
      updateData.fechaAceptacion = new Date();
      updateData.motivoRechazo = null;
    } else if (estado === 'rechazada') {
      updateData.fechaRechazo = new Date();
      updateData.motivoRechazo = motivoRechazo;
    }

    const factura = await prisma.factura.update({
      where: { id },
      data: updateData,
      include: {
        proveedor: {
          select: {
            id: true,
            nombre: true
          }
        }
      }
    });

    return NextResponse.json(factura);
  } catch (error) {
    console.error('Error updating factura estado:', error);
    return NextResponse.json(
      { error: 'Error al actualizar estado de factura' },
      { status: 500 }
    );
  }
}
