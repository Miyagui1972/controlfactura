import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// PATCH: Cambiar estado de pago de factura
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { id } = params;
    const body = await request.json();
    const { estadoPago } = body;

    if (!estadoPago || !['pagada', 'porPagar'].includes(estadoPago)) {
      return NextResponse.json(
        { error: 'Estado de pago inválido. Debe ser "pagada" o "porPagar"' },
        { status: 400 }
      );
    }

    // Verificar que la factura existe
    const facturaExistente = await prisma.factura.findUnique({
      where: { id },
      include: {
        negocio: true
      }
    });

    if (!facturaExistente) {
      return NextResponse.json(
        { error: 'Factura no encontrada' },
        { status: 404 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    if (facturaExistente.negocio.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    const factura = await prisma.factura.update({
      where: { id },
      data: { estadoPago },
      include: {
        proveedor: {
          select: {
            id: true,
            nombre: true
          }
        }
      }
    });

    return NextResponse.json(factura);
  } catch (error) {
    console.error('Error updating factura pago:', error);
    return NextResponse.json(
      { error: 'Error al actualizar estado de pago' },
      { status: 500 }
    );
  }
}
