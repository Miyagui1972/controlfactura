import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// PUT: Editar factura
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { id } = params;
    const body = await request.json();
    const {
      proveedorId,
      rutEmpresa,
      numeroFactura,
      fechaEmision,
      fechaVencimiento,
      nombreVendedor,
      formaPago,
      totalNeto,
      iva,
      total
    } = body;

    if (!numeroFactura || !fechaEmision || !fechaVencimiento || !totalNeto) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' },
        { status: 400 }
      );
    }

    // Verificar que la factura existe
    const facturaExistente = await prisma.factura.findUnique({
      where: { id },
      include: {
        negocio: true
      }
    });

    if (!facturaExistente) {
      return NextResponse.json(
        { error: 'Factura no encontrada' },
        { status: 404 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    if (facturaExistente.negocio.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    const factura = await prisma.factura.update({
      where: { id },
      data: {
        proveedorId,
        rutEmpresa,
        numeroFactura,
        fechaEmision: new Date(fechaEmision),
        fechaVencimiento: new Date(fechaVencimiento),
        nombreVendedor,
        formaPago,
        totalNeto: parseFloat(totalNeto),
        iva: parseFloat(iva ?? 0),
        total: parseFloat(total)
      },
      include: {
        proveedor: {
          select: {
            id: true,
            nombre: true
          }
        }
      }
    });

    return NextResponse.json(factura);
  } catch (error) {
    console.error('Error updating factura:', error);
    return NextResponse.json(
      { error: 'Error al actualizar factura' },
      { status: 500 }
    );
  }
}

// DELETE: Eliminar factura
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { id } = params;

    // Obtener la factura con sus relaciones
    const factura = await prisma.factura.findUnique({
      where: { id },
      include: {
        negocio: true,
        proveedor: true
      }
    });

    if (!factura) {
      return NextResponse.json(
        { error: 'Factura no encontrada' },
        { status: 404 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    if (factura.negocio.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 403 }
      );
    }

    // Registrar en auditoría
    await prisma.auditoria.create({
      data: {
        userId: session.user.id,
        tipoRegistro: 'Factura',
        datosEliminados: JSON.stringify({
          id: factura.id,
          numeroFactura: factura.numeroFactura,
          proveedor: factura.proveedor.nombre,
          total: factura.total,
          estado: factura.estado,
          estadoPago: factura.estadoPago
        }),
        negocioId: factura.negocioId
      }
    });

    // Eliminar factura
    await prisma.factura.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting factura:', error);
    return NextResponse.json(
      { error: 'Error al eliminar factura' },
      { status: 500 }
    );
  }
}
