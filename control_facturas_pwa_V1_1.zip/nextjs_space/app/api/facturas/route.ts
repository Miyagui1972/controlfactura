import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth-options';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET: Listar facturas con filtros
export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const negocioId = searchParams.get('negocioId');
    const proveedorId = searchParams.get('proveedorId');
    const estado = searchParams.get('estado');
    const estadoPago = searchParams.get('estadoPago');
    const fechaInicio = searchParams.get('fechaInicio');
    const fechaFin = searchParams.get('fechaFin');

    if (!negocioId) {
      return NextResponse.json(
        { error: 'negocioId es requerido' },
        { status: 400 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    const negocio = await prisma.negocio.findFirst({
      where: {
        id: negocioId,
        userId: session.user.id
      }
    });

    if (!negocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    // Construir filtros
    const where: any = { negocioId };
    
    if (proveedorId) {
      where.proveedorId = proveedorId;
    }
    
    if (estado) {
      where.estado = estado;
    }
    
    if (estadoPago) {
      where.estadoPago = estadoPago;
    }
    
    if (fechaInicio || fechaFin) {
      where.fechaEmision = {};
      if (fechaInicio) {
        where.fechaEmision.gte = new Date(fechaInicio);
      }
      if (fechaFin) {
        where.fechaEmision.lte = new Date(fechaFin);
      }
    }

    const facturas = await prisma.factura.findMany({
      where,
      include: {
        proveedor: {
          select: {
            id: true,
            nombre: true
          }
        }
      },
      orderBy: {
        fechaEmision: 'desc'
      }
    });

    return NextResponse.json(facturas);
  } catch (error) {
    console.error('Error fetching facturas:', error);
    return NextResponse.json(
      { error: 'Error al obtener facturas' },
      { status: 500 }
    );
  }
}

// POST: Crear factura
export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const {
      negocioId,
      proveedorId,
      rutEmpresa,
      numeroFactura,
      fechaEmision,
      fechaVencimiento,
      nombreVendedor,
      formaPago,
      totalNeto,
      iva,
      total
    } = body;

    if (!negocioId || !proveedorId || !numeroFactura || !fechaEmision || !fechaVencimiento || !totalNeto) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' },
        { status: 400 }
      );
    }

    // Verificar que el negocio pertenece al usuario
    const negocio = await prisma.negocio.findFirst({
      where: {
        id: negocioId,
        userId: session.user.id
      }
    });

    if (!negocio) {
      return NextResponse.json(
        { error: 'Negocio no encontrado' },
        { status: 404 }
      );
    }

    // Verificar que el proveedor existe y pertenece al negocio
    const proveedor = await prisma.proveedor.findFirst({
      where: {
        id: proveedorId,
        negocioId: negocioId
      }
    });

    if (!proveedor) {
      return NextResponse.json(
        { error: 'Proveedor no encontrado' },
        { status: 404 }
      );
    }

    const factura = await prisma.factura.create({
      data: {
        negocioId,
        proveedorId,
        rutEmpresa,
        numeroFactura,
        fechaEmision: new Date(fechaEmision),
        fechaVencimiento: new Date(fechaVencimiento),
        nombreVendedor,
        formaPago,
        totalNeto: parseFloat(totalNeto),
        iva: parseFloat(iva ?? 0),
        total: parseFloat(total),
        estado: 'pendiente',
        estadoPago: 'porPagar'
      },
      include: {
        proveedor: {
          select: {
            id: true,
            nombre: true
          }
        }
      }
    });

    return NextResponse.json(factura, { status: 201 });
  } catch (error) {
    console.error('Error creating factura:', error);
    return NextResponse.json(
      { error: 'Error al crear factura' },
      { status: 500 }
    );
  }
}
