'use client';

import { AuthGuard } from '@/components/auth-guard';
import FacturasContent from '@/components/facturas-content';

export default function FacturasPage() {
  return (
    <AuthGuard>
      <FacturasContent />
    </AuthGuard>
  );
}
