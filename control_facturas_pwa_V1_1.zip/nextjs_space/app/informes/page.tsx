'use client';

import { AuthGuard } from '@/components/auth-guard';
import InformesContent from '@/components/informes-content';

export default function InformesPage() {
  return (
    <AuthGuard>
      <InformesContent />
    </AuthGuard>
  );
}
