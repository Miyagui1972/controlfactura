'use client';

import { AuthGuard } from '@/components/auth-guard';
import AuditoriaContent from '@/components/auditoria-content';

export default function AuditoriaPage() {
  return (
    <AuthGuard>
      <AuditoriaContent />
    </AuthGuard>
  );
}
