'use client';

import { AuthGuard } from '@/components/auth-guard';
import ComprasSinBoletaContent from '@/components/compras-sin-boleta-content';

export default function ComprasSinBoletaPage() {
  return (
    <AuthGuard>
      <ComprasSinBoletaContent />
    </AuthGuard>
  );
}
