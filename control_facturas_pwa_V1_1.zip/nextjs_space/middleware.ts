export { default } from "next-auth/middleware"

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/negocios/:path*",
    "/proveedores/:path*",
    "/facturas/:path*",
    "/compras-sin-boleta/:path*",
    "/auditoria/:path*",
    "/informes/:path*",
    "/notificaciones/:path*"
  ]
}
