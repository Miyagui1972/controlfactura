import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed de la base de datos...');

  // Limpiar datos existentes
  await prisma.notificacion.deleteMany();
  await prisma.auditoria.deleteMany();
  await prisma.compraSinBoleta.deleteMany();
  await prisma.factura.deleteMany();
  await prisma.proveedor.deleteMany();
  await prisma.negocio.deleteMany();
  await prisma.session.deleteMany();
  await prisma.account.deleteMany();
  await prisma.user.deleteMany();

  // Crear usuario de prueba
  const hashedPassword = await bcrypt.hash('johndoe123', 10);
  const user = await prisma.user.create({
    data: {
      email: 'john@doe.com',
      password: hashedPassword,
      name: 'John Doe',
      emailVerified: new Date(),
    },
  });
  console.log('✓ Usuario de prueba creado:', user.email);

  // Crear negocios
  const negocio1 = await prisma.negocio.create({
    data: {
      userId: user.id,
      nombre: 'Distribuidora El Sol',
      descripcion: 'Distribuidora de productos de consumo masivo',
    },
  });

  const negocio2 = await prisma.negocio.create({
    data: {
      userId: user.id,
      nombre: 'Restaurante La Esquina',
      descripcion: 'Restaurante de comida tradicional',
    },
  });

  const negocio3 = await prisma.negocio.create({
    data: {
      userId: user.id,
      nombre: 'Ferretería Los Andes',
      descripcion: 'Venta de herramientas y materiales de construcción',
    },
  });
  console.log('✓ 3 negocios creados');

  // Crear proveedores para Distribuidora El Sol
  const prov1 = await prisma.proveedor.create({
    data: {
      negocioId: negocio1.id,
      nombre: 'Coca-Cola Embonor',
      direccion: 'Av. Providencia 1234, Santiago',
      telefono: '+56 2 2345 6789',
    },
  });

  const prov2 = await prisma.proveedor.create({
    data: {
      negocioId: negocio1.id,
      nombre: 'Nestlé Chile',
      direccion: 'Av. Apoquindo 4501, Las Condes',
      telefono: '+56 2 2987 6543',
    },
  });

  const prov3 = await prisma.proveedor.create({
    data: {
      negocioId: negocio1.id,
      nombre: 'Carozzi S.A.',
      direccion: 'Camino Longitudinal Sur 5201, San Bernardo',
      telefono: '+56 2 2456 7890',
    },
  });

  // Crear proveedores para Restaurante La Esquina
  const prov4 = await prisma.proveedor.create({
    data: {
      negocioId: negocio2.id,
      nombre: 'Frigorífico Central',
      direccion: 'Av. Vicuña Mackenna 8765, La Florida',
      telefono: '+56 2 2765 4321',
    },
  });

  const prov5 = await prisma.proveedor.create({
    data: {
      negocioId: negocio2.id,
      nombre: 'Distribuidora de Verduras Fresco',
      direccion: 'Lo Valledor 1234, Santiago',
      telefono: '+56 9 8765 4321',
    },
  });

  // Crear proveedores para Ferretería Los Andes
  const prov6 = await prisma.proveedor.create({
    data: {
      negocioId: negocio3.id,
      nombre: 'Cementos Bío Bío',
      direccion: 'Av. Industrial 987, Quilicura',
      telefono: '+56 2 2333 4444',
    },
  });

  const prov7 = await prisma.proveedor.create({
    data: {
      negocioId: negocio3.id,
      nombre: 'Sodimac Proveedor Mayorista',
      direccion: 'Av. Américo Vespucio 1501, Vitacura',
      telefono: '+56 2 2555 6666',
    },
  });
  console.log('✓ 7 proveedores creados');

  // Función auxiliar para crear fechas
  const today = new Date();
  const getDate = (daysOffset: number) => {
    const date = new Date(today);
    date.setDate(date.getDate() + daysOffset);
    return date;
  };

  // Crear facturas variadas para Distribuidora El Sol
  // Factura 1: Aceptada y Pagada
  await prisma.factura.create({
    data: {
      proveedorId: prov1.id,
      negocioId: negocio1.id,
      rutEmpresa: '96.928.510-K',
      numeroFactura: '000125478',
      fechaEmision: getDate(-60),
      fechaVencimiento: getDate(-30),
      nombreVendedor: 'Carlos Pérez',
      formaPago: 'Credito',
      totalNeto: 1500000,
      iva: 285000,
      total: 1785000,
      estado: 'Aceptada',
      estadoPago: 'Pagada',
      fechaAceptacion: getDate(-55),
    },
  });

  // Factura 2: Aceptada y Por pagar (vence en 5 días)
  await prisma.factura.create({
    data: {
      proveedorId: prov1.id,
      negocioId: negocio1.id,
      rutEmpresa: '96.928.510-K',
      numeroFactura: '000125479',
      fechaEmision: getDate(-25),
      fechaVencimiento: getDate(5),
      nombreVendedor: 'Carlos Pérez',
      formaPago: 'Credito',
      totalNeto: 2800000,
      iva: 532000,
      total: 3332000,
      estado: 'Aceptada',
      estadoPago: 'Por pagar',
      fechaAceptacion: getDate(-20),
    },
  });

  // Factura 3: Rechazada
  await prisma.factura.create({
    data: {
      proveedorId: prov2.id,
      negocioId: negocio1.id,
      rutEmpresa: '91.120.000-8',
      numeroFactura: 'FAC-8765432',
      fechaEmision: getDate(-45),
      fechaVencimiento: getDate(-15),
      nombreVendedor: 'María González',
      formaPago: 'Contado',
      totalNeto: 950000,
      iva: 180500,
      total: 1130500,
      estado: 'Rechazada',
      estadoPago: 'Por pagar',
      fechaRechazo: getDate(-40),
      motivoRechazo: 'Productos recibidos en mal estado. No coincide con la orden de compra.',
    },
  });

  // Factura 4: Pendiente (por revisar)
  await prisma.factura.create({
    data: {
      proveedorId: prov3.id,
      negocioId: negocio1.id,
      rutEmpresa: '99.347.000-0',
      numeroFactura: 'F-456789',
      fechaEmision: getDate(-10),
      fechaVencimiento: getDate(20),
      nombreVendedor: 'Roberto Silva',
      formaPago: 'Credito',
      totalNeto: 3200000,
      iva: 608000,
      total: 3808000,
      estado: 'Pendiente',
      estadoPago: 'Por pagar',
    },
  });

  // Factura 5: Aceptada y Pagada (Contado)
  await prisma.factura.create({
    data: {
      proveedorId: prov2.id,
      negocioId: negocio1.id,
      rutEmpresa: '91.120.000-8',
      numeroFactura: 'FAC-8765433',
      fechaEmision: getDate(-20),
      fechaVencimiento: getDate(-20),
      nombreVendedor: 'María González',
      formaPago: 'Contado',
      totalNeto: 1200000,
      iva: 228000,
      total: 1428000,
      estado: 'Aceptada',
      estadoPago: 'Pagada',
      fechaAceptacion: getDate(-19),
    },
  });

  // Crear facturas para Restaurante La Esquina
  // Factura 6: Aceptada y Por pagar
  await prisma.factura.create({
    data: {
      proveedorId: prov4.id,
      negocioId: negocio2.id,
      rutEmpresa: '76.123.456-7',
      numeroFactura: 'FC-2024-001234',
      fechaEmision: getDate(-15),
      fechaVencimiento: getDate(15),
      nombreVendedor: 'Luis Martínez',
      formaPago: 'Credito',
      totalNeto: 850000,
      iva: 161500,
      total: 1011500,
      estado: 'Aceptada',
      estadoPago: 'Por pagar',
      fechaAceptacion: getDate(-12),
    },
  });

  // Factura 7: Pendiente
  await prisma.factura.create({
    data: {
      proveedorId: prov5.id,
      negocioId: negocio2.id,
      rutEmpresa: '77.987.654-3',
      numeroFactura: 'VD-5678',
      fechaEmision: getDate(-5),
      fechaVencimiento: getDate(10),
      nombreVendedor: 'Ana Torres',
      formaPago: 'Credito',
      totalNeto: 320000,
      iva: 60800,
      total: 380800,
      estado: 'Pendiente',
      estadoPago: 'Por pagar',
    },
  });

  // Factura 8: Aceptada y Pagada
  await prisma.factura.create({
    data: {
      proveedorId: prov4.id,
      negocioId: negocio2.id,
      rutEmpresa: '76.123.456-7',
      numeroFactura: 'FC-2024-001200',
      fechaEmision: getDate(-40),
      fechaVencimiento: getDate(-10),
      nombreVendedor: 'Luis Martínez',
      formaPago: 'Credito',
      totalNeto: 1100000,
      iva: 209000,
      total: 1309000,
      estado: 'Aceptada',
      estadoPago: 'Pagada',
      fechaAceptacion: getDate(-38),
    },
  });

  // Crear facturas para Ferretería Los Andes
  // Factura 9: Aceptada y Por pagar (vence en 3 días)
  await prisma.factura.create({
    data: {
      proveedorId: prov6.id,
      negocioId: negocio3.id,
      rutEmpresa: '93.896.000-1',
      numeroFactura: 'CBB-987654',
      fechaEmision: getDate(-27),
      fechaVencimiento: getDate(3),
      nombreVendedor: 'Pedro Ramírez',
      formaPago: 'Credito',
      totalNeto: 4500000,
      iva: 855000,
      total: 5355000,
      estado: 'Aceptada',
      estadoPago: 'Por pagar',
      fechaAceptacion: getDate(-25),
    },
  });

  // Factura 10: Rechazada
  await prisma.factura.create({
    data: {
      proveedorId: prov7.id,
      negocioId: negocio3.id,
      rutEmpresa: '96.792.430-K',
      numeroFactura: 'SDM-556677',
      fechaEmision: getDate(-50),
      fechaVencimiento: getDate(-20),
      nombreVendedor: 'Claudia Díaz',
      formaPago: 'Credito',
      totalNeto: 2100000,
      iva: 399000,
      total: 2499000,
      estado: 'Rechazada',
      estadoPago: 'Por pagar',
      fechaRechazo: getDate(-48),
      motivoRechazo: 'Cantidad incorrecta de productos entregados. Falta el 30% del pedido.',
    },
  });

  // Factura 11: Aceptada y Pagada
  await prisma.factura.create({
    data: {
      proveedorId: prov6.id,
      negocioId: negocio3.id,
      rutEmpresa: '93.896.000-1',
      numeroFactura: 'CBB-987650',
      fechaEmision: getDate(-70),
      fechaVencimiento: getDate(-40),
      nombreVendedor: 'Pedro Ramírez',
      formaPago: 'Credito',
      totalNeto: 3800000,
      iva: 722000,
      total: 4522000,
      estado: 'Aceptada',
      estadoPago: 'Pagada',
      fechaAceptacion: getDate(-68),
    },
  });

  // Factura 12: Pendiente (vence pronto - 6 días)
  await prisma.factura.create({
    data: {
      proveedorId: prov7.id,
      negocioId: negocio3.id,
      rutEmpresa: '96.792.430-K',
      numeroFactura: 'SDM-556688',
      fechaEmision: getDate(-24),
      fechaVencimiento: getDate(6),
      nombreVendedor: 'Claudia Díaz',
      formaPago: 'Credito',
      totalNeto: 1700000,
      iva: 323000,
      total: 2023000,
      estado: 'Pendiente',
      estadoPago: 'Por pagar',
    },
  });

  console.log('✓ 12 facturas creadas');

  // Crear compras sin boleta
  await prisma.compraSinBoleta.create({
    data: {
      negocioId: negocio1.id,
      fechaIngreso: getDate(-15),
      monto: 25000,
      tipoCompra: 'Artículos de limpieza',
      nombreProducto: 'Cloro, detergente, escobas',
    },
  });

  await prisma.compraSinBoleta.create({
    data: {
      negocioId: negocio2.id,
      fechaIngreso: getDate(-8),
      monto: 45000,
      tipoCompra: 'Ingredientes frescos',
      nombreProducto: 'Verduras y especias del mercado',
    },
  });

  await prisma.compraSinBoleta.create({
    data: {
      negocioId: negocio2.id,
      fechaIngreso: getDate(-3),
      monto: 18000,
      tipoCompra: 'Suministros varios',
      nombreProducto: 'Servilletas y vasos desechables',
    },
  });

  await prisma.compraSinBoleta.create({
    data: {
      negocioId: negocio3.id,
      fechaIngreso: getDate(-20),
      monto: 35000,
      tipoCompra: 'Herramientas pequeñas',
      nombreProducto: 'Alicates, destornilladores, cinta métrica',
    },
  });

  await prisma.compraSinBoleta.create({
    data: {
      negocioId: negocio3.id,
      fechaIngreso: getDate(-12),
      monto: 52000,
      tipoCompra: 'Material eléctrico',
      nombreProducto: 'Cables, enchufes, interruptores',
    },
  });

  console.log('✓ 5 compras sin boleta creadas');

  // Crear registros de auditoría simulando eliminaciones previas
  await prisma.auditoria.create({
    data: {
      userId: user.id,
      negocioId: negocio1.id,
      tipoRegistro: 'Proveedor',
      datosEliminados: JSON.stringify({
        nombre: 'Proveedor ABC Ltda.',
        direccion: 'Calle Falsa 123',
        telefono: '+56 2 2222 3333',
      }),
      fechaEliminacion: getDate(-90),
    },
  });

  await prisma.auditoria.create({
    data: {
      userId: user.id,
      negocioId: negocio2.id,
      tipoRegistro: 'Factura',
      datosEliminados: JSON.stringify({
        numeroFactura: 'FAC-OLD-001',
        proveedor: 'Proveedor Antiguo',
        total: 500000,
        motivo: 'Factura duplicada',
      }),
      fechaEliminacion: getDate(-60),
    },
  });

  await prisma.auditoria.create({
    data: {
      userId: user.id,
      negocioId: negocio3.id,
      tipoRegistro: 'CompraSinBoleta',
      datosEliminados: JSON.stringify({
        monto: 15000,
        tipoCompra: 'Materiales diversos',
        nombreProducto: 'Tornillos y clavos',
      }),
      fechaEliminacion: getDate(-30),
    },
  });

  console.log('✓ 3 registros de auditoría creados');

  // Crear notificaciones de facturas próximas a vencer
  const facturasProximasVencer = await prisma.factura.findMany({
    where: {
      estadoPago: 'Por pagar',
      fechaVencimiento: {
        gte: today,
        lte: getDate(7),
      },
    },
    include: {
      proveedor: true,
    },
  });

  for (const factura of facturasProximasVencer) {
    const diasRestantes = Math.ceil(
      (factura.fechaVencimiento.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
    );
    await prisma.notificacion.create({
      data: {
        userId: user.id,
        negocioId: factura.negocioId,
        facturaId: factura.id,
        mensaje: `La factura ${factura.numeroFactura} del proveedor ${factura.proveedor.nombre} vence en ${diasRestantes} día(s). Monto: $${factura.total.toLocaleString('es-CL')}`,
        leida: false,
      },
    });
  }

  console.log(`✓ ${facturasProximasVencer.length} notificaciones creadas`);

  console.log('\n✅ Seed completado exitosamente!');
  console.log('📧 Usuario de prueba: john@doe.com');
  console.log('🔑 Contraseña: johndoe123');
}

main()
  .catch((e) => {
    console.error('❌ Error durante el seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
